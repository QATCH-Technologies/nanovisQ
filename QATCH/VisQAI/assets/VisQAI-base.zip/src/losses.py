import torch
import torch.nn as nn
import numpy as np

TAG = "[ViscosityLoss]"


class ViscosityLoss(nn.Module):
    """
    Improved loss function with:
    1. More aggressive weighting for low shear rates
    2. Optional adaptive weighting based on performance
    3. Combined MSE and MAE for robustness
    4. Relative error component
    """

    def __init__(self,
                 shear_weights: torch.Tensor = None,
                 use_adaptive_weights: bool = False,
                 mse_weight: float = 0.6,
                 mae_weight: float = 0.3,
                 relative_weight: float = 0.1,
                 adaptive_momentum: float = 0.95) -> None:
        super().__init__()

        # Much more aggressive initial weights for low shear rates
        # These correspond to shear rates: 100, 1000, 10000, 100000, 15000000 s^-1
        # Stronger emphasis on low rates
        default_weights = [4.0, 3.0, 1.5, 1.0, 1.0]

        self.register_buffer(
            'base_shear_weights',
            shear_weights if shear_weights is not None else torch.tensor(
                default_weights)
        )

        self.use_adaptive_weights = use_adaptive_weights
        self.mse_weight = mse_weight
        self.mae_weight = mae_weight
        self.relative_weight = relative_weight
        self.adaptive_momentum = adaptive_momentum

        # For adaptive weighting - track running errors per shear rate
        if self.use_adaptive_weights:
            self.register_buffer(
                'running_errors',
                torch.ones(len(default_weights))
            )

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # Input validation
        if torch.isnan(pred).any() or torch.isinf(pred).any():
            raise ValueError("NaN/inf detected in predictions")
        if torch.isnan(target).any() or torch.isinf(target).any():
            raise ValueError("NaN/inf detected in targets")

        # Get current weights
        if self.use_adaptive_weights and self.training:
            weights = self._compute_adaptive_weights(pred, target)
        else:
            weights = self.base_shear_weights

        weights = weights.to(pred.device)

        # 1. Weighted MSE Loss (primary component)
        mse = (pred - target) ** 2
        if mse.shape[1] == len(weights):
            weighted_mse = mse * weights.unsqueeze(0)
        else:
            weighted_mse = mse
        mse_loss = weighted_mse.mean()

        # 2. Weighted MAE Loss (more robust to outliers)
        mae = torch.abs(pred - target)
        if mae.shape[1] == len(weights):
            weighted_mae = mae * weights.unsqueeze(0)
        else:
            weighted_mae = mae
        mae_loss = weighted_mae.mean()

        # 3. Relative Error Loss (helps with scale differences)
        # Since targets are log-transformed viscosity, exp to get actual scale
        actual_pred = torch.exp(pred)
        actual_target = torch.exp(target)

        # Relative error: |pred - target| / (target + epsilon)
        epsilon = 1e-6
        relative_error = torch.abs(
            actual_pred - actual_target) / (actual_target + epsilon)

        if relative_error.shape[1] == len(weights):
            weighted_relative = relative_error * weights.unsqueeze(0)
        else:
            weighted_relative = relative_error
        relative_loss = weighted_relative.mean()

        # Combine losses
        total_loss = (
            self.mse_weight * mse_loss +
            self.mae_weight * mae_loss +
            self.relative_weight * relative_loss
        )

        # Final validation
        if torch.isnan(total_loss) or torch.isinf(total_loss):
            raise ValueError("NaN/inf detected in loss computation")

        return total_loss

    def _compute_adaptive_weights(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        Compute adaptive weights based on current per-shear-rate performance.
        Shear rates with higher errors get higher weights.
        """
        with torch.no_grad():
            # Compute current batch errors per shear rate
            batch_errors = torch.abs(
                pred - target).mean(dim=0)  # [num_shear_rates]

            # Update running errors with momentum
            self.running_errors = (
                self.adaptive_momentum * self.running_errors +
                (1 - self.adaptive_momentum) * batch_errors.cpu()
            )

            # Normalize errors to create weights
            # Higher error -> higher weight
            normalized_errors = self.running_errors / \
                (self.running_errors.mean() + 1e-8)

            # Combine with base weights
            adaptive_weights = self.base_shear_weights.cpu() * normalized_errors

            # Renormalize to maintain similar scale
            adaptive_weights = adaptive_weights * \
                len(adaptive_weights) / adaptive_weights.sum()

            return adaptive_weights.to(pred.device)

    def get_current_weights(self) -> torch.Tensor:
        """Return current weights (useful for logging)"""
        if self.use_adaptive_weights:
            return self._compute_adaptive_weights(
                torch.zeros(1, len(self.base_shear_weights)),
                torch.zeros(1, len(self.base_shear_weights))
            )
        return self.base_shear_weights


class HuberLossWithWeights(nn.Module):
    """
    Alternative: Huber loss (smooth L1) with shear rate weighting.
    More robust to outliers than MSE, smoother than MAE.
    """

    def __init__(self,
                 shear_weights: torch.Tensor = None,
                 delta: float = 1.0) -> None:
        super().__init__()

        default_weights = [4.0, 3.0, 1.5, 1.0, 1.0]
        self.register_buffer(
            'shear_weights',
            shear_weights if shear_weights is not None else torch.tensor(
                default_weights)
        )
        self.delta = delta
        self.huber = nn.SmoothL1Loss(reduction='none', beta=delta)

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        if torch.isnan(pred).any() or torch.isinf(pred).any():
            raise ValueError("NaN/inf detected in predictions")
        if torch.isnan(target).any() or torch.isinf(target).any():
            raise ValueError("NaN/inf detected in targets")

        # Compute Huber loss
        huber_loss = self.huber(pred, target)

        # Apply shear rate weights
        weights = self.shear_weights.to(pred.device)
        if huber_loss.shape[1] == len(weights):
            weighted_loss = huber_loss * weights.unsqueeze(0)
        else:
            weighted_loss = huber_loss

        total_loss = weighted_loss.mean()

        if torch.isnan(total_loss) or torch.isinf(total_loss):
            raise ValueError("NaN/inf in loss computation")

        return total_loss


class FocalMSELoss(nn.Module):
    """
    Focal loss variant for regression - focuses more on hard examples.
    Helps with difficult low shear rate predictions.
    """

    def __init__(self,
                 shear_weights: torch.Tensor = None,
                 gamma: float = 2.0) -> None:
        super().__init__()

        default_weights = [4.0, 3.0, 1.5, 1.0, 1.0]
        self.register_buffer(
            'shear_weights',
            shear_weights if shear_weights is not None else torch.tensor(
                default_weights)
        )
        self.gamma = gamma

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        if torch.isnan(pred).any() or torch.isinf(pred).any():
            raise ValueError("NaN/inf detected in predictions")
        if torch.isnan(target).any() or torch.isinf(target).any():
            raise ValueError("NaN/inf detected in targets")

        # Compute MSE
        mse = (pred - target) ** 2

        # Focal weight: higher weight for larger errors
        # Normalize errors to [0, 1] range for stability
        normalized_error = torch.sigmoid(torch.abs(pred - target))
        focal_weight = normalized_error ** self.gamma

        # Apply focal and shear weights
        weighted_mse = mse * focal_weight

        weights = self.shear_weights.to(pred.device)
        if weighted_mse.shape[1] == len(weights):
            weighted_mse = weighted_mse * weights.unsqueeze(0)

        total_loss = weighted_mse.mean()

        if torch.isnan(total_loss) or torch.isinf(total_loss):
            raise ValueError("NaN/inf in loss computation")

        return total_loss
