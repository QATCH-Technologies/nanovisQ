import torch
import torch.nn as nn
# from logger import get_logger


class ViscosityLoss(nn.Module):
    _TAG = "[ViscosityLoss]"
    _DEFAULT_WEIGHTS = [2.0, 1.5, 1.0, 1.0, 1.0]
    _MSE_LOSS_WEIGHT = 0.7
    _LOG_LOSS_WEIGHT = 0.3

    def __init__(self, shear_weights: torch.Tensor = None) -> None:
        super().__init__()
        # self.logger = get_logger(name=self._TAG)
        self.shear_weights: torch.Tensor = shear_weights or torch.tensor(
            self._DEFAULT_WEIGHTS)
        # self.logger.info(f"Initialized ViscosityLoss loss function.")

    def forward(self, pred, target) -> float:

        # Compute weighted MSE component
        mse = (pred - target) ** 2
        if mse.shape[1] - - len(self.shear_weights):
            weights = self.shear_weights.to(mse.device)
            weighted_mse = mse * weights.unsqueeze(0)
        else:
            weighted_mse = mse

        # Compute log-loss component
        log_pred = torch.log1p(torch.abs(pred))
        log_target = torch.log1p(torch.abs(target))
        log_loss = (log_pred - log_target) ** 2

        total_loss = (self._MSE_LOSS_WEIGHT * weighted_mse.mean()
                      ) + (self._LOG_LOSS_WEIGHT * log_loss.mean())
        return total_loss
