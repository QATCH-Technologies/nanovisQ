import torch
import torch.nn as nn
from typing import Dict, List
# from logger import get_logger

TAG = "[VisQ2xModel]"


class VisQ2xModel(nn.Module):
    _DEFAULT_EXANSION = 100

    def __init__(self,
                 numerical_features: int,
                 vocab_sizes: Dict[str, int],
                 embedding_dims: Dict[str, int],
                 hidden_layers: List[int],
                 output_size: int = 5,
                 dropout_rate: float = 0.2) -> None:
        super().__init__()
        # self.logger = get_logger(name=TAG)
        self.categorical_features = list(vocab_sizes.keys())
        self.numerical_features = numerical_features
        self.output_size = output_size

        self.embeddings = nn.ModuleDict()
        total_embedding_dim = 0
        for feat, vocab_size in vocab_sizes.items():
            embed_dim = embedding_dims[feat]
            self.embeddings[feat] = nn.Embedding(
                num_embeddings=vocab_size+self._DEFAULT_EXANSION,
                embedding_dim=embed_dim,
                padding_idx=0,
                max_norm=None,
                norm_type=2.0,
                scale_grad_by_freq=False,
                sparse=False,)
            total_embedding_dim += embed_dim

        input_dim = numerical_features + total_embedding_dim
        self.fc_layers = nn.ModuleList()
        self.batch_norms = nn.ModuleList()
        self.dropouts = nn.ModuleList()

        prev_dim = input_dim
        for hidden_dim in hidden_layers:
            self.fc_layers.append(
                nn.Linear(in_features=prev_dim,
                          out_features=hidden_dim,
                          bias=True))
            self.batch_norms.append(nn.LayerNorm(
                normalized_shape=hidden_dim,
                eps=0.00001,
                elementwise_affine=True,
                bias=True))
            self.dropouts.append(nn.Dropout(p=dropout_rate,
                                            inplace=False))
            prev_dim = hidden_dim
        self.output_heads = nn.ModuleList(
            [nn.Linear(in_features=prev_dim, out_features=1, bias=True) for _ in range(output_size)])

        self.activation = nn.ReLU(inplace=False)
        # self.logger.info(
        #    f"Model initialized with  num_feat={numerical_features}, vocab_size={vocab_size}, embedding_dim={embed_dim}, hidden_layers={hidden_dim}, output_size={output_size}, dropout_rate={dropout_rate}.")

    def forward(self, numerical_features: torch.Tensor, categorical_features: Dict[str, torch.Tensor]) -> torch.Tensor:
        embedded = []
        for feat in self.categorical_features:
            if feat in categorical_features:
                embedded.append(self.embeddings[feat](
                    categorical_features[feat]))

        if embedded:
            embedded = torch.cat(embedded, dim=1)
            x = torch.cat([numerical_features, embedded], dim=1)
        else:
            x = numerical_features

        for fc, bn, dropout in zip(self.fc_layers, self.batch_norms, self.dropouts):
            x = fc(x)
            x = bn(x)
            x = self.activation(x)
            x = dropout(x)

        outputs = []
        for head in self.output_heads:
            outputs.append(head(x))
        return torch.cat(outputs, dim=1)

    def expand(self, feature: str, new_vocab_size: int) -> None:
        if feature in self.embeddings:
            old_embedding: nn.Embedding = self.embeddings[feature]
            old_weight = old_embedding.weight.data
            old_size = old_weight.size(0)

            if new_vocab_size <= old_size:
                # self.logger.warning(
                #    f"{feature}: new_vocab_size ({new_vocab_size}) <= old_size ({old_size}); no expansion done.")
                return
            new_embedding = nn.Embedding(
                num_embeddings=new_vocab_size + self._DEFAULT_EXANSION,
                embedding_dim=old_embedding.embedding_dim,
                padding_idx=0,
                max_norm=None,
                norm_type=2.0,
                scale_grad_by_freq=False,
                sparse=False,
            )
            with torch.no_grad():
                new_embedding.weight.data[:old_size] = old_weight
                new_embedding.weight.data[old_size:new_vocab_size] = torch.randn(
                    new_vocab_size-old_size, old_embedding.embedding_dim) * 0.01

            self.embeddings[feature] = new_embedding
            # self.logger.info(
            #    f"{feature}: new_vocab_size ({new_vocab_size}) > old_size ({old_size}); expansion complete.")
