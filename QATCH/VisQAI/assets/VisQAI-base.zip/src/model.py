import torch
import torch.nn as nn
from typing import Dict, List
import math

TAG = "[VisQ2xModel]"


class MultiHeadAttention(nn.Module):
    """Attention mechanism to relate predictions across shear rates"""

    def __init__(self, hidden_dim: int, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.num_heads = num_heads
        self.hidden_dim = hidden_dim
        self.head_dim = hidden_dim // num_heads

        assert hidden_dim % num_heads == 0, "hidden_dim must be divisible by num_heads"

        self.qkv = nn.Linear(hidden_dim, hidden_dim * 3)
        self.proj = nn.Linear(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.scale = math.sqrt(self.head_dim)

    def forward(self, x):
        # x shape: [batch, seq_len, hidden_dim]
        batch_size, seq_len, _ = x.shape

        # Generate Q, K, V
        qkv = self.qkv(x).reshape(batch_size, seq_len,
                                  3, self.num_heads, self.head_dim)
        # [3, batch, heads, seq_len, head_dim]
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        # Attention scores
        attn = (q @ k.transpose(-2, -1)) / self.scale
        attn = torch.softmax(attn, dim=-1)
        attn = self.dropout(attn)

        # Apply attention
        out = attn @ v
        out = out.transpose(1, 2).reshape(batch_size, seq_len, self.hidden_dim)
        out = self.proj(out)

        return out


class ShearRateSpecificBranch(nn.Module):
    """Dedicated branch for each shear rate with residual connections"""

    def __init__(self, input_dim: int, branch_hidden: List[int], dropout: float = 0.2):
        super().__init__()

        self.layers = nn.ModuleList()
        prev_dim = input_dim

        for hidden_dim in branch_hidden:
            self.layers.append(nn.Sequential(
                nn.Linear(prev_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout)
            ))
            prev_dim = hidden_dim

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x


class VisQ2xModel(nn.Module):
    """
    Improved viscosity prediction model with:
    1. Shared feature extraction backbone
    2. Shear-rate-specific processing branches  
    3. Cross-shear-rate attention mechanism
    4. Residual connections throughout
    5. Enhanced capacity for low shear rates
    """
    _DEFAULT_EXPANSION = 100

    def __init__(self,
                 numerical_features: int,
                 vocab_sizes: Dict[str, int],
                 embedding_dims: Dict[str, int],
                 hidden_layers: List[int],
                 output_size: int = 5,
                 dropout_rate: float = 0.2,
                 conv_channels: List[int] = None,
                 conv_kernel_sizes: List[int] = None,
                 use_attention: bool = True,
                 use_shear_branches: bool = True,
                 branch_hidden: List[int] = None) -> None:
        super().__init__()

        self.categorical_features = list(vocab_sizes.keys())
        self.numerical_features = numerical_features
        self.output_size = output_size
        self.use_attention = use_attention
        self.use_shear_branches = use_shear_branches

        # Embedding layers for categorical features (unchanged)
        self.embeddings = nn.ModuleDict()
        total_embedding_dim = 0
        for feat, vocab_size in vocab_sizes.items():
            embed_dim = embedding_dims[feat]
            self.embeddings[feat] = nn.Embedding(
                num_embeddings=vocab_size + self._DEFAULT_EXPANSION,
                embedding_dim=embed_dim,
                padding_idx=0)
            total_embedding_dim += embed_dim

        input_dim = numerical_features + total_embedding_dim

        # Enhanced convolutional backbone with residual connections
        # if self.use_conv and conv_channels:
        #     self.conv_layers = nn.ModuleList()
        #     self.conv_residuals = nn.ModuleList()

        #     if conv_kernel_sizes is None:
        #         conv_kernel_sizes = [3] * len(conv_channels)

        #     prev_channels = 1
        #     for i, (out_channels, kernel_size) in enumerate(zip(conv_channels, conv_kernel_sizes)):
        #         padding = kernel_size // 2

        #         # Main conv block
        #         conv_block = nn.Sequential(
        #             nn.Conv1d(prev_channels, out_channels,
        #                       kernel_size, padding=padding),
        #             nn.BatchNorm1d(out_channels),
        #             nn.ReLU(),
        #             nn.Dropout(dropout_rate)
        #         )
        #         self.conv_layers.append(conv_block)

        #         # Residual connection (1x1 conv for dimension matching)
        #         if prev_channels != out_channels:
        #             self.conv_residuals.append(
        #                 nn.Conv1d(prev_channels, out_channels, 1)
        #             )
        #         else:
        #             self.conv_residuals.append(nn.Identity())

        #         prev_channels = out_channels

        #     self.global_pool = nn.AdaptiveAvgPool1d(1)
        #     fc_input_dim = conv_channels[-1]
        # else:
        self.conv_layers = None
        fc_input_dim = input_dim

        # Shared fully connected backbone with residual connections
        self.fc_layers = nn.ModuleList()
        self.fc_residuals = nn.ModuleList()

        prev_dim = fc_input_dim
        for hidden_dim in hidden_layers:
            fc_block = nn.Sequential(
                nn.Linear(prev_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            )
            self.fc_layers.append(fc_block)

            # Residual connection
            if prev_dim != hidden_dim:
                self.fc_residuals.append(nn.Linear(prev_dim, hidden_dim))
            else:
                self.fc_residuals.append(nn.Identity())

            prev_dim = hidden_dim

        # Shear-rate-specific processing branches
        if self.use_shear_branches:
            if branch_hidden is None:
                branch_hidden = [128, 64]  # Additional capacity per shear rate

            self.shear_branches = nn.ModuleList([
                ShearRateSpecificBranch(prev_dim, branch_hidden, dropout_rate)
                for _ in range(output_size)
            ])
            branch_output_dim = branch_hidden[-1]
        else:
            branch_output_dim = prev_dim

        # Cross-shear-rate attention (helps relate predictions)
        if self.use_attention:
            self.attention = MultiHeadAttention(
                hidden_dim=branch_output_dim,
                num_heads=4,
                dropout=dropout_rate
            )
            self.attention_norm = nn.LayerNorm(branch_output_dim)

        # Final output heads with additional layer for better fitting
        self.output_heads = nn.ModuleList()
        for _ in range(output_size):
            head = nn.Sequential(
                nn.Linear(branch_output_dim, branch_output_dim // 2),
                nn.ReLU(),
                nn.Dropout(dropout_rate / 2),  # Less dropout in final layer
                nn.Linear(branch_output_dim // 2, 1)
            )
            self.output_heads.append(head)

        self.activation = nn.ReLU()

    def forward(self,
                numerical_features: torch.Tensor,
                categorical_features: Dict[str, torch.Tensor]) -> torch.Tensor:

        # Input validation (can be removed in production)
        if torch.isnan(numerical_features).any():
            raise ValueError("Input contains NaN")

        # Embed categorical features
        embedded = []
        for feat in self.categorical_features:
            if feat in categorical_features:
                cat_input = categorical_features[feat]
                emb = self.embeddings[feat](cat_input)
                if torch.isnan(emb).any():
                    raise ValueError(f"Embedding '{feat}' produced NaN")
                embedded.append(emb)

        # Concatenate features
        if embedded:
            embedded = torch.cat(embedded, dim=1)
            x = torch.cat([numerical_features, embedded], dim=1)
        else:
            x = numerical_features

        # Convolutional processing with residuals
        # if self.use_conv and self.conv_layers:
        #     x = x.unsqueeze(1)

        #     for conv_block, residual in zip(self.conv_layers, self.conv_residuals):
        #         identity = residual(x)
        #         x = conv_block(x) + identity  # Residual connection

        #     x = self.global_pool(x).squeeze(-1)

        # Shared FC backbone with residuals
        for fc_block, residual in zip(self.fc_layers, self.fc_residuals):
            identity = residual(x)
            x = fc_block(x) + identity  # Residual connection

        # Shear-rate-specific processing
        if self.use_shear_branches:
            branch_outputs = []
            for branch in self.shear_branches:
                branch_out = branch(x)
                branch_outputs.append(branch_out)

            # Stack for attention: [batch, num_shear_rates, hidden_dim]
            stacked = torch.stack(branch_outputs, dim=1)

            # Cross-shear-rate attention
            if self.use_attention:
                attn_out = self.attention(stacked)
                stacked = self.attention_norm(stacked + attn_out)  # Residual

            # Apply output heads
            outputs = []
            for i, head in enumerate(self.output_heads):
                out = head(stacked[:, i, :])
                outputs.append(out)
        else:
            # Standard path without branches
            outputs = []
            for head in self.output_heads:
                out = head(x)
                outputs.append(out)

        result = torch.cat(outputs, dim=1)

        if torch.isnan(result).any():
            raise ValueError("Final output contains NaN")

        return result

    def expand(self, feature: str, new_vocab_size: int) -> None:
        """Dynamically expand vocabulary size for a categorical feature."""
        if feature in self.embeddings:
            old_embedding = self.embeddings[feature]
            old_weight = old_embedding.weight.data
            old_size = old_weight.size(0)

            if new_vocab_size <= old_size:
                return

            new_embedding = nn.Embedding(
                num_embeddings=new_vocab_size + self._DEFAULT_EXPANSION,
                embedding_dim=old_embedding.embedding_dim,
                padding_idx=0)

            with torch.no_grad():
                new_embedding.weight.data[:old_size] = old_weight
                nn.init.xavier_uniform_(
                    new_embedding.weight.data[old_size:new_vocab_size]
                )

            self.embeddings[feature] = new_embedding
