from dataclasses import dataclass
from typing import List


@dataclass
class VisQ2xConfig:
    embedding_dim: int = 48
    hidden_layers: List[int] = None
    dropout_rate: float = 15000000000000002
    learning_rate: float = 0.006622877043156895
    batch_size: int = 64
    epochs: int = 200
    early_stopping_patience: int = 20
    ewc_lambda: float = 0.5
    replay_buffer_size: int = 100
    adaptation_lr: float = 0.0001

    def __post_init__(self) -> None:
        if self.hidden_layers is None:
            self.hidden_layers = [256, 160]
