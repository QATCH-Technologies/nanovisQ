
import torch
import torch.nn as nn
from typing import Dict, List
from dataclasses import dataclass

TAG = "[VisQ2xConfig]"


@dataclass
class VisQ2xConfig:
    embedding_dim: int = 48
    conv_channels: List[int] = None  # e.g., [64, 128, 256]
    conv_kernel_sizes: List[int] = None  # e.g., [3, 3, 3]
    hidden_layers: List[int] = None
    dropout_rate: float = 0.2
    learning_rate: float = 0.006622877043156895
    batch_size: int = 64
    epochs: int = 200
    early_stopping_patience: int = 20
    ewc_lambda: float = 0.5
    replay_buffer_size: int = 100
    adaptation_lr: float = 0.0001
    use_conv: bool = True  # Toggle convolutions on/off
    # Separate dropout for conv layers (uses dropout_rate if None)
    conv_dropout_rate: float = None

    def __post_init__(self) -> None:
        if self.hidden_layers is None:
            self.hidden_layers = [256, 160]
        if self.conv_channels is None:
            self.conv_channels = [64, 128, 128]
        if self.conv_kernel_sizes is None:
            self.conv_kernel_sizes = [3, 3, 3]
        if self.conv_dropout_rate is None:
            self.conv_dropout_rate = self.dropout_rate
