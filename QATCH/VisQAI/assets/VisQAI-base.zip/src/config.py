import torch
import torch.nn as nn
from typing import Dict, List, Optional
from dataclasses import dataclass, field

TAG = "[VisQ2xConfig]"


@dataclass
class VisQ2xConfig:
    """
    Improved configuration with enhanced architecture and training strategies
    for better low shear rate performance.
    """

    # ==================== Model Architecture ====================
    embedding_dim: int = 64  # Increased from 48

    # Enhanced conv layers - more channels and depth
    conv_channels: List[int] = field(default_factory=lambda: [96, 192, 256])
    conv_kernel_sizes: List[int] = field(default_factory=lambda: [5, 3, 3])

    # Deeper FC layers with more capacity
    hidden_layers: List[int] = field(default_factory=lambda: [384, 256, 192])

    # Shear-rate-specific branches
    use_shear_branches: bool = True
    branch_hidden: List[int] = field(default_factory=lambda: [128, 96])

    # Cross-shear-rate attention
    use_attention: bool = True

    # Regularization
    dropout_rate: float = 0.25  # Slightly increased
    conv_dropout_rate: Optional[float] = 0.2
    weight_decay: float = 1e-5  # L2 regularization

    # ==================== Training Hyperparameters ====================
    learning_rate: float = 0.003  # Reduced from 0.0066
    batch_size: int = 48  # Reduced for better gradients
    epochs: int = 300  # Increased for convergence
    early_stopping_patience: int = 30

    # Learning rate scheduling
    use_lr_scheduler: bool = True
    scheduler_type: str = "cosine"  # Options: "cosine", "plateau", "step"
    lr_warmup_epochs: int = 10
    lr_min: float = 1e-6

    # ==================== Loss Configuration ====================
    loss_type: str = "improved"  # Options: "improved", "huber", "focal", "original"

    # Improved loss weights - MORE aggressive for low shear rates
    shear_weights: List[float] = field(
        default_factory=lambda: [5.0, 3.5, 2.0, 1.2, 1.0])

    use_adaptive_weights: bool = True  # Enable adaptive weighting
    mse_weight: float = 0.6
    mae_weight: float = 0.3
    relative_weight: float = 0.1

    # ==================== Advanced Training Strategies ====================
    # Curriculum learning - train on easier shear rates first
    use_curriculum: bool = True
    curriculum_epochs: int = 50  # How long to use curriculum

    # Multi-stage training with different loss weights
    use_multistage: bool = True
    stage1_epochs: int = 100  # Focus on all shear rates equally
    stage2_epochs: int = 100  # Focus more on low shear rates
    stage3_epochs: int = 100  # Final fine-tuning

    # Gradient clipping for stability
    gradient_clip_value: float = 1.0

    # Mixed precision training
    use_mixed_precision: bool = True

    # ==================== Continual Learning ====================
    ewc_lambda: float = 0.5
    replay_buffer_size: int = 150  # Increased
    adaptation_lr: float = 0.0005

    # ==================== Data Augmentation ====================
    use_augmentation: bool = True
    noise_std: float = 0.02  # Add small noise to numerical features

    # ==================== Ensemble Settings ====================
    use_ensemble: bool = False  # Train multiple models
    num_ensemble_models: int = 3

    def __post_init__(self) -> None:
        """Validation and default value setup"""
        if self.conv_dropout_rate is None:
            self.conv_dropout_rate = self.dropout_rate

        # Validate shear weights length
        if len(self.shear_weights) != 5:
            raise ValueError(
                "shear_weights must have length 5 (one per shear rate)")

        # Validate scheduler type
        valid_schedulers = ["cosine", "plateau", "step", "none"]
        if self.scheduler_type not in valid_schedulers:
            raise ValueError(
                f"scheduler_type must be one of {valid_schedulers}")

        # Validate loss type
        valid_losses = ["improved", "huber", "focal", "original"]
        if self.loss_type not in valid_losses:
            raise ValueError(f"loss_type must be one of {valid_losses}")

    def get_optimizer(self, model: nn.Module) -> torch.optim.Optimizer:
        """Get configured optimizer"""
        return torch.optim.AdamW(
            model.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
            betas=(0.9, 0.999)
        )

    def get_scheduler(self, optimizer: torch.optim.Optimizer, total_steps: int):
        """Get configured learning rate scheduler"""
        if not self.use_lr_scheduler or self.scheduler_type == "none":
            return None

        if self.scheduler_type == "cosine":
            from torch.optim.lr_scheduler import CosineAnnealingLR
            return CosineAnnealingLR(
                optimizer,
                T_max=total_steps - self.lr_warmup_epochs,
                eta_min=self.lr_min
            )
        elif self.scheduler_type == "plateau":
            from torch.optim.lr_scheduler import ReduceLROnPlateau
            return ReduceLROnPlateau(
                optimizer,
                mode='min',
                factor=0.5,
                patience=10,
                min_lr=self.lr_min
            )
        elif self.scheduler_type == "step":
            from torch.optim.lr_scheduler import StepLR
            return StepLR(
                optimizer,
                step_size=50,
                gamma=0.5
            )

        return None

    def to_dict(self) -> Dict:
        """Convert config to dictionary"""
        return {
            'embedding_dim': self.embedding_dim,
            'conv_channels': self.conv_channels,
            'conv_kernel_sizes': self.conv_kernel_sizes,
            'hidden_layers': self.hidden_layers,
            'use_shear_branches': self.use_shear_branches,
            'branch_hidden': self.branch_hidden,
            'use_attention': self.use_attention,
            'dropout_rate': self.dropout_rate,
            'learning_rate': self.learning_rate,
            'batch_size': self.batch_size,
            'epochs': self.epochs,
            'loss_type': self.loss_type,
            'shear_weights': self.shear_weights,
            'use_adaptive_weights': self.use_adaptive_weights,
            'use_curriculum': self.use_curriculum,
            'use_multistage': self.use_multistage,
        }


# ==================== Preset Configurations ====================

@dataclass
class BalancedConfig(VisQ2xConfig):
    """Balanced configuration - good starting point"""
    shear_weights: List[float] = field(
        default_factory=lambda: [4.0, 3.0, 1.5, 1.0, 1.0])
    hidden_layers: List[int] = field(default_factory=lambda: [384, 256, 192])
    learning_rate: float = 0.003


@dataclass
class LowShearFocusedConfig(VisQ2xConfig):
    """Maximum focus on low shear rates - most aggressive"""
    shear_weights: List[float] = field(
        default_factory=lambda: [10.0, 7.0, 3.0, 1.5, 1.0])
    use_adaptive_weights: bool = True
    use_curriculum: bool = True
    hidden_layers: List[int] = field(default_factory=lambda: [512, 384, 256])
    branch_hidden: List[int] = field(default_factory=lambda: [192, 128])
    learning_rate: float = 0.002
    batch_size: int = 32


@dataclass
class FastTrainingConfig(VisQ2xConfig):
    """Faster training with reasonable performance"""
    hidden_layers: List[int] = field(default_factory=lambda: [256, 192])
    conv_channels: List[int] = field(default_factory=lambda: [64, 128, 192])
    branch_hidden: List[int] = field(default_factory=lambda: [96, 64])
    epochs: int = 150
    learning_rate: float = 0.005
    batch_size: int = 64
    use_curriculum: bool = False


@dataclass
class HighCapacityConfig(VisQ2xConfig):
    """Maximum model capacity - slowest but potentially best"""
    embedding_dim: int = 96
    conv_channels: List[int] = field(
        default_factory=lambda: [128, 256, 384, 512])
    conv_kernel_sizes: List[int] = field(default_factory=lambda: [7, 5, 3, 3])
    hidden_layers: List[int] = field(
        default_factory=lambda: [768, 512, 384, 256])
    branch_hidden: List[int] = field(default_factory=lambda: [256, 192, 128])
    dropout_rate: float = 0.3
    shear_weights: List[float] = field(
        default_factory=lambda: [8.0, 6.0, 3.0, 1.5, 1.0])
    batch_size: int = 32
    learning_rate: float = 0.001
    epochs: int = 400
