import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from sklearn.preprocessing import RobustScaler
from typing import Dict, Tuple, List, Optional

from config import VisQ2xConfig
from encoding import Embedder
# from logger import get_logger

TAG = "[IO]"
CATEGORICAL = [
    'Protein_type', 'Protein_class_type', 'Buffer_type',
    'Salt_type', 'Stabilizer_type', 'Surfactant_type', 'Excipient_type'
]

NUMERIC = [
    'MW', 'Protein_conc', 'Temperature', 'Buffer_pH',
    'Buffer_conc', 'Salt_conc', 'Stabilizer_conc', 'Surfactant_conc', 'Excipient_conc', "kP"
]

TARGETS = [
    'Viscosity_100', 'Viscosity_1000', 'Viscosity_10000',
    'Viscosity_100000', 'Viscosity_15000000'
]


class Common:
    def __init__(self, config: VisQ2xConfig = None) -> None:
        # self.logger = get_logger(name=TAG)
        self.config = config or VisQ2xConfig()
        self.device = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu")

        self.embedder = Embedder()
        self.scaler = RobustScaler()
        self.model = None

        self.categorical = CATEGORICAL
        self.numeric = NUMERIC
        self.targets = TARGETS
        # self.logger.info(
        #    f"Initialized IO module with config {self.config} to device {self.device}")

    def preprocess(self, df: pd.DataFrame, fit_scalers: bool = False) -> Tuple:
        df = df.copy()

        # Fill missing values for categorical columns
        for col in self.categorical:
            if col in df.columns:
                df[col] = df[col].fillna('none')
        for col in ['PI_mean', 'Buffer_pH', 'MW', 'C_Class']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        # pI - pH
        if 'PI_mean' in df.columns and 'Buffer_pH' in df.columns:
            df['pI_minus_pH'] = df['PI_mean'] - df['Buffer_pH']

        # Δ (Delta) = pH - pI (opposite sign from pI_minus_pH)
        if 'PI_mean' in df.columns and 'Buffer_pH' in df.columns:
            df['Delta'] = df['Buffer_pH'] - df['PI_mean']

        # kH = |pI - pH| / MW^(2/3)
        # Surface density normalization
        if 'PI_mean' in df.columns and 'Buffer_pH' in df.columns and 'MW' in df.columns:
            df['kH'] = np.abs(df['PI_mean'] - df['Buffer_pH']
                              ) / (df['MW'] ** (2/3))

        # CCI (Charge-Class Index) = C_class * exp(-|Δ|/τ) with τ = 1.5
        if 'C_Class' in df.columns and 'Delta' in df.columns:
            tau = 1.5
            df['CCI'] = df['C_Class'] * np.exp(-np.abs(df['Delta']) / tau)

        # Update numeric features list to include new features (avoid duplicates)
        new_features = []
        if 'pI_minus_pH' in df.columns and 'pI_minus_pH' not in self.numeric:
            new_features.append('pI_minus_pH')
        if 'Delta' in df.columns and 'Delta' not in self.numeric:
            new_features.append('Delta')
        if 'kH' in df.columns and 'kH' not in self.numeric:
            new_features.append('kH')
        if 'CCI' in df.columns and 'CCI' not in self.numeric:
            new_features.append('CCI')
        if 'HCI' in df.columns and 'HCI' not in self.numeric:
            new_features.append('HCI')

        self.numeric.extend(new_features)

        # === CATEGORICAL ENCODING ===
        df = self.classify_regime(df)
        if 'Regime' not in self.categorical:
            self.categorical.append('Regime')
        if fit_scalers:
            self.embedder.fit(df=df, columns=self.categorical,
                              embedding_dim=self.config.embedding_dim)
        cat_encoded = self.embedder.transform(df=df)

        # Fill missing values for numeric columns
        for col in self.numeric:
            if col in df.columns:
                if fit_scalers:
                    median_val = df[col].median()
                    self.numerical_medians = getattr(
                        self, "numerical_medians", {})
                    self.numerical_medians[col] = median_val
                df[col] = df[col].fillna(self.numerical_medians.get(col, 0))

        # === NUMERIC SCALING ===
        # Create a proper DataFrame with column names
        num_df = pd.DataFrame(
            df[self.numeric].values,
            columns=self.numeric,
            index=df.index
        )

        if fit_scalers:
            # Fit on DataFrame - this MUST capture feature names in sklearn >= 1.0
            num_scaled = self.scaler.fit_transform(num_df)

            # Manual fallback for older sklearn versions
            if not hasattr(self.scaler, 'feature_names_in_'):
                self.scaler.feature_names_in_ = np.array(self.numeric)
        else:
            num_scaled = self.scaler.transform(num_df)

        # === TARGET PROCESSING ===
        targets = None
        if all(col in df.columns for col in self.targets):
            targets = df[self.targets].values
            targets = np.log1p(targets)

        return num_scaled, cat_encoded, targets

    def classify_regime(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Classify formulation regime based on CCI and protein class.

        Based on Table B from Excipient_Identifiers.pdf:
        - Near-pI: Electrostatic-dominated
        - Mixed: Intermediate regime
        - Far: Hydrophobic/crowding-dominated

        Args:
            df: DataFrame with 'CCI' and 'Protein_class_type' columns

        Returns:
            DataFrame with added 'Regime' column
        """
        df = df.copy()

        if 'C_Class' not in df.columns:
            raise ValueError(
                "C_Class column must be computed before regime classification")

        if 'Protein_class_type' not in df.columns:
            raise ValueError(
                "Protein_class_type column required for regime classification")

        # Define regime thresholds per protein class (from Table B)
        regime_thresholds = {
            'mAb_IgG1': {'near': 0.90, 'mixed': 0.50},
            'mAb_IgG4': {'near': 0.80, 'mixed': 0.40},
            'Fc-Fusion': {'near': 0.70, 'mixed': 0.40},
            'Trispecific': {'near': 0.70, 'mixed': 0.40},
            'ADC': {'near': 0.80, 'mixed': 0.45},
            'Bispecific': {'near': 0.80, 'mixed': 0.45},
            'other': {'near': 0.70, 'mixed': 0.40},
            'polyclonal': {'near': 0.70, 'mixed': 0.40},
        }

        def get_regime(row):
            protein_class = row['Protein_class_type']
            cci = row['CCI']

            # Default thresholds if class not found
            thresholds = regime_thresholds.get(
                protein_class, {'near': 0.75, 'mixed': 0.45})

            if cci >= thresholds['near']:
                return 'Near'
            elif cci >= thresholds['mixed']:
                return 'Mixed'
            else:
                return 'Far'

        df['Regime'] = df.apply(get_regime, axis=1)

        return df

    def create_loaders(self,
                       numeric: np.ndarray,
                       categoric: Dict[str, np.ndarray],
                       targets: Optional[np.ndarray],
                       batch_size: int = None,
                       shuffle: bool = True) -> DataLoader:
        batch_size = batch_size or self.config.batch_size
        num_tensor = torch.FloatTensor(numeric)
        cat_tensor = {k: torch.LongTensor(v) for k, v in categoric.items()}
        targets_tensor = torch.FloatTensor(
            targets) if targets is not None else None

        dataset = []
        for i in range(len(num_tensor)):
            cat_dict = {k: v[i] for k, v in cat_tensor.items()}
            if targets_tensor is not None:
                dataset.append((num_tensor[i], cat_dict, targets_tensor[i]))
            else:
                dataset.append((num_tensor[i], cat_dict))
        # self.logger.info(f"DataLoader created with batch size {batch_size}")
        return DataLoader(dataset, batch_size=batch_size, shuffle=True)

    def save_state(self, path: str, addons: Dict = None) -> None:
        if self.model is None:
            raise ValueError("Model is not trained; unable to save assets.")

        # Get scaler feature names if available
        scaler_feature_names = None
        if self.scaler is not None and hasattr(self.scaler, 'feature_names_in_'):
            scaler_feature_names = self.scaler.feature_names_in_.tolist()

        state = {
            'model_state': self.model.state_dict(),
            'config': self.config.__dict__,
            'scaler': self.scaler,
            'scaler_feature_names': scaler_feature_names,
            'embedder': self.embedder,
            'numerical_medians': getattr(self, 'numerical_medians', {}),
            'numeric_cols': self.numeric,
            'target_cols': self.targets,
        }

        if addons:
            state.update(addons)

        torch.save(state, path)

    def load_state(self, path: str) -> Dict:
        assets = torch.load(path, map_location=self.device, weights_only=False)

        self.config = VisQ2xConfig(**assets["config"])
        self.scaler = assets["scaler"]
        self.scaler_feature_names = assets.get("scaler_feature_names", None)
        self.embedder = assets["embedder"]
        self.numerical_medians = assets.get('numerical_medians', {})
        return assets
