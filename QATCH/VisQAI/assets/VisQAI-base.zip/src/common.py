import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from sklearn.preprocessing import RobustScaler
from typing import Dict, Tuple, List, Optional

from config import VisQ2xConfig
from encoding import Embedder
# from logger import get_logger

TAG = "[IO]"
CATEGORICAL = [
    'Protein_type', 'Protein_class_type', 'Buffer_type',
    'Salt_type', 'Stabilizer_type', 'Surfactant_type', 'Excipient_type'
]

NUMERIC = [
    'MW', 'Protein_conc', 'Temperature', 'Buffer_pH',
    'Buffer_conc', 'Salt_conc', 'Stabilizer_conc', 'Surfactant_conc', 'Excipient_conc', "kP"
]

TARGETS = [
    'Viscosity_100', 'Viscosity_1000', 'Viscosity_10000',
    'Viscosity_100000', 'Viscosity_15000000'
]


class Common:
    def __init__(self, config: VisQ2xConfig = None) -> None:
        # self.logger = get_logger(name=TAG)
        self.config = config or VisQ2xConfig()
        self.device = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu")

        self.embedder = Embedder()
        self.scaler = RobustScaler()
        self.model = None

        self.categorical = CATEGORICAL
        self.numeric = NUMERIC
        self.targets = TARGETS
        # self.logger.info(
        #    f"Initialized IO module with config {self.config} to device {self.device}")

    def preprocess(self, df: pd.DataFrame, fit_scalers: bool = False) -> Tuple:
        df = df.copy()

        # Fill missing values for numeric columns
        for col in self.numeric:
            if col in df.columns:
                if fit_scalers:
                    median_val = df[col].median()
                    self.numerical_medians = getattr(
                        self, "numerical_medians", {})
                    self.numerical_medians[col] = median_val
                df[col] = df[col].fillna(self.numerical_medians.get(col, 0))

        # Fill missing values for categorical columns
        for col in self.categorical:
            if col in df.columns:
                df[col] = df[col].fillna('none')

        # pI - pH
        if 'pI' in df.columns and 'pH' in df.columns:
            df['pI_minus_pH'] = df['pI'] - df['pH']

        # kH = |pI - pH| / MW^(2/3)
        # Surface density normalization
        if 'pI' in df.columns and 'pH' in df.columns and 'MW' in df.columns:
            df['kH'] = np.abs(df['pI'] - df['pH']) / (df['MW'] ** (2/3))

        # Update numeric features list to include new features
        numeric_features = self.numeric.copy()
        if 'pI_minus_pH' in df.columns:
            numeric_features.append('pI_minus_pH')
        if 'kH' in df.columns:
            numeric_features.append('kH')
        # === CATEGORICAL ENCODING ===
        if fit_scalers:
            self.embedder.fit(df=df, columns=self.categorical,
                              embedding_dim=self.config.embedding_dim)
        cat_encoded = self.embedder.transform(df=df)

        # === NUMERIC SCALING ===
        num_data = df[numeric_features].values
        if fit_scalers:
            num_scaled = self.scaler.fit_transform(num_data)
        else:
            num_scaled = self.scaler.transform(num_data)

        # === TARGET PROCESSING ===
        targets = None
        if all(col in df.columns for col in self.targets):
            targets = df[self.targets].values
            targets = np.log1p(targets)

        return num_scaled, cat_encoded, targets

    def create_loaders(self,
                       numeric: np.ndarray,
                       categoric: Dict[str, np.ndarray],
                       targets: Optional[np.ndarray],
                       batch_size: int = None,
                       shuffle: bool = True) -> DataLoader:
        batch_size = batch_size or self.config.batch_size
        num_tensor = torch.FloatTensor(numeric)
        cat_tensor = {k: torch.LongTensor(v) for k, v in categoric.items()}
        targets_tensor = torch.FloatTensor(
            targets) if targets is not None else None

        dataset = []
        for i in range(len(num_tensor)):
            cat_dict = {k: v[i] for k, v in cat_tensor.items()}
            if targets_tensor is not None:
                dataset.append((num_tensor[i], cat_dict, targets_tensor[i]))
            else:
                dataset.append((num_tensor[i], cat_dict))
        # self.logger.info(f"DataLoader created with batch size {batch_size}")
        return DataLoader(dataset, batch_size=batch_size, shuffle=True)

    def save_state(self, path: str, addons: Dict = None) -> None:
        if self.model is None:
            # self.logger.error("Model is not trained; unable to save assets.")
            raise ValueError
        state = {
            'model_state': self.model.state_dict(),
            'config': self.config.__dict__,
            'scaler': self.scaler,
            'embedder': self.embedder,
            'numerical_medians': getattr(self, 'numerical_medians', {}),
        }

        if addons:
            state.update(addons)

        torch.save(state, path)
        # self.logger.info(f"Saved model assets to path {path}.")

    def load_state(self, path: str) -> Dict:
        assets = torch.load(path, map_location=self.device, weights_only=False)

        self.config = VisQ2xConfig(**assets["config"])
        self.scaler = assets["scaler"]
        self.embedder = assets["embedder"]
        self.numerical_medians = assets.get('numerical_medians', {})
        # self.logger.info(f"Recovered assets from path {path}.")
        return assets
