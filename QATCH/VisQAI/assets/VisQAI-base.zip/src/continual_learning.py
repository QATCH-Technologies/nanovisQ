import torch
import numpy as np
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Dict, Any, Tuple, List, Optional
# from logger import get_logger


class EWC:
    _TAG = "[EWC]"

    def __init__(self, model: nn.Module, dataset: DataLoader, device: str = 'cpu'):
        self.model: nn.Module = model
        self.device = device
        self.params = {n: p.clone().detach()
                       for n, p in model.named_parameters()}
        self.fisher = self._compute_fisher(dataset)

    def _compute_fisher(self, dataset: DataLoader) -> Dict[str, torch.Tensor]:
        """Fixed indentation - division happens outside batch loop"""
        fisher = {}
        self.model.eval()
        for n, p in self.model.named_parameters():
            fisher[n] = torch.zeros_like(p)

        for batch in dataset:
            num, cat, targets = batch
            num = num.to(self.device)
            cat = {k: v.to(self.device) for k, v in cat.items()}
            targets = targets.to(self.device)

            self.model.zero_grad()
            output = self.model(num, cat)
            loss = nn.MSELoss()(output, targets)
            loss.backward()

            for n, p in self.model.named_parameters():
                if p.grad is not None:
                    fisher[n] += p.grad.data ** 2

        for n in fisher:
            fisher[n] /= len(dataset)
        return fisher

    def penalty(self, selective_layers: Optional[List[str]] = None) -> torch.Tensor:
        """
        Compute EWC penalty with optional selective layer application

        Args:
            selective_layers: If provided, only apply EWC to layers whose names contain these strings
        """
        loss = 0
        for n, p in self.model.named_parameters():
            # Skip if selective layers specified and this layer not in list
            if selective_layers is not None:
                if not any(layer_name in n for layer_name in selective_layers):
                    continue

            if n in self.fisher:
                loss += (self.fisher[n] * (p - self.params[n]) ** 2).sum()

        # self.logger.info(f"Applying penalty of {loss}.")
        return loss


class DynamicEWC(EWC):
    """EWC with dynamic lambda that decays over training"""

    def __init__(self, model: nn.Module, dataset: DataLoader, device: str = 'cpu',
                 initial_lambda: float = 1000.0, final_lambda: float = 100.0,
                 decay_epochs: int = 10):
        super().__init__(model, dataset, device)
        self.initial_lambda = initial_lambda
        self.final_lambda = final_lambda
        self.decay_epochs = decay_epochs
        self.current_epoch = 0

    def get_lambda(self) -> float:
        """Get current lambda value based on epoch"""
        if self.current_epoch >= self.decay_epochs:
            return self.final_lambda

        # Linear decay
        progress = self.current_epoch / self.decay_epochs
        return self.initial_lambda - (self.initial_lambda - self.final_lambda) * progress

    def step_epoch(self):
        """Call at the end of each epoch to update lambda"""
        self.current_epoch += 1


class ERB:
    _TAG = "[ExperienceReplayBuffer]"

    def __init__(self, max_size: int = 100) -> None:
        self.max_size = max_size
        self.buffer = []

    def add(self, experience: Tuple[Any, ...]) -> None:
        if len(self.buffer) >= self.max_size:
            self.buffer.pop(0)
        self.buffer.append(experience)

    def sample(self, batch_size: int) -> List[Tuple[Any, ...]]:
        if len(self.buffer) < batch_size:
            return self.buffer

        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        sample = [self.buffer[i] for i in indices]
        return sample

    def update(self, dataset: DataLoader, n_samples: int = 100) -> None:
        for i, batch in enumerate(dataset):
            if i >= n_samples:
                break
            self.add(batch)


class AdaptiveLearningScheduler:
    """Scheduler that starts with higher learning rate for aggressive adaptation"""

    def __init__(self, optimizer, initial_lr: float, final_lr: float,
                 warmup_epochs: int = 5, total_epochs: int = 50):
        self.optimizer = optimizer
        self.initial_lr = initial_lr
        self.final_lr = final_lr
        self.warmup_epochs = warmup_epochs
        self.total_epochs = total_epochs
        self.current_epoch = 0

    def step(self):
        """Update learning rate"""
        if self.current_epoch < self.warmup_epochs:
            # Linear warmup from final_lr to initial_lr
            progress = self.current_epoch / self.warmup_epochs
            lr = self.final_lr + (self.initial_lr - self.final_lr) * progress
        else:
            # Cosine decay from initial_lr to final_lr
            progress = (self.current_epoch - self.warmup_epochs) / \
                (self.total_epochs - self.warmup_epochs)
            lr = self.final_lr + (self.initial_lr - self.final_lr) * \
                0.5 * (1 + np.cos(np.pi * progress))

        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr

        self.current_epoch += 1
        return lr
