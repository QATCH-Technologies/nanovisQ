import torch
import numpy as np
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Dict, Any, Tuple, List
# from logger import get_logger


class EWC:
    _TAG = "[EWC]"

    def __init__(self, model: nn.Module, dataset: DataLoader, device: str = 'cpu'):
        # self.logger = get_logger(name=self._TAG)
        self.model: nn.Module = model
        self.device = device
        self.params = {n: p.clone().detach()
                       for n, p in model.named_parameters()}
        self.fisher = self._compute_fisher(dataset)
        # self.logger.info(
        #    f"Initialized Elastic-Weight-Consolidation module using {self.model} on {self.device} with params {self.params}")

    def _compute_fisher(self, dataset: DataLoader) -> Dict[str, torch.Tensor]:
        fisher = {}
        self.model.eval()
        for n, p in self.model.named_parameters():
            fisher[n] = torch.zeros_like(p)

        for batch in dataset:
            num, cat, targets = batch
            num = num.to(self.device)
            cat = {k: v.to(self.device) for k, v in cat.items()}
            targets = targets.to(self.device)

            self.model.zero_grad()
            output = self.model(num, cat)
            loss = nn.MSELoss()(output, targets)
            loss.backward()

            for n, p in self.model.named_parameters():
                if p.grad is not None:
                    fisher[n] += p.grad.data ** 2

            for n in fisher:
                fisher[n] /= len(dataset)
            # self.logger.info("Computed fisher matrix for EWC module.")
            return fisher

    def penalty(self) -> torch.Tensor:
        loss = 0
        for n, p in self.model.named_parameters():
            if n in self.fisher:
                loss += (self.fisher[n] * (p - self.params[n]) ** 2).sum()

        # self.logger.info(f"Applying penalty of {loss}.")
        return loss


class ERB:
    _TAG = "[ExperienceReplayBuffer]"

    def __init__(self, max_size: int = 100) -> None:
        # self.logger = get_logger(name=self._TAG)
        self.max_size = max_size
        self.buffer = []
        # self.logger.info(
        #    f"Initialized Expereince-Replay-Buffer with size {self.max_size}.")

    def add(self, experience: Tuple[Any, ...]) -> None:
        if len(self.buffer) >= self.max_size:
            self.buffer.pop(0)
        self.buffer.append(experience)
        # self.logger.info("Added 1 experience to ERB.")

    def sample(self, batch_size: int) -> List[Tuple[Any, ...]]:
        if len(self.buffer) < batch_size:
            # self.logger.info(f"Sampling {len(self.buffer)} samples from ERB.")
            return self.buffer

        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        sample = [self.buffer[i] for i in indices]
        # self.logger.info(f"Sampling {len(sample)} samples from ERB.")
        return sample

    def update(self, dataset: DataLoader, n_samples: int = 100) -> None:
        # self.logger.info(f'Updating ERB with {n_samples} samples.')
        for i, batch in enumerate(dataset):
            if i >= n_samples:
                break
            self.add(batch)
