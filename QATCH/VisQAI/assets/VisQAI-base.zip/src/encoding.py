import numpy as np
import pandas as pd
from typing import Dict, List
# from logger import get_logger

TAG = "[Embedder]"


class Embedder:
    def __init__(self) -> None:
        # self.logger = get_logger(name=TAG)
        self.mappings = {}
        self.embedding_dims = {}
        self.unkown_token = "<UNK>"
        # self.logger.info("Embedding initialized.")

    def fit(self, df: pd.DataFrame, columns: List[str], embedding_dim: int = 16) -> None:
        for col in columns:
            unique_vals = df[col].dropna().unique().tolist()
            unique_vals.append(self.unkown_token)
            self.mappings[col] = {val: idx for idx,
                                  val in enumerate(unique_vals)}
            n_categories = len(unique_vals)
            self.embedding_dims[col] = min(
                embedding_dim, max(2, n_categories//2))
        # self.logger.info(f"Fit embedder with dim {self.embedding_dims}")

    def transform(self, df: pd.DataFrame) -> Dict[str, np.ndarray]:
        encoded = {}
        for col, mapping in self.mappings.items():
            if col in df.columns:
                encoded[col] = df[col].apply(lambda x: mapping.get(
                    x, mapping[self.unkown_token])).values
            else:
                encoded[col] = np.full(len(df), mapping[self.unkown_token])
        return encoded

    def add(self, column: str, new_category: str) -> bool:
        if column in self.mappings:
            if new_category not in self.mappings[column]:
                max_idx = len(self.mappings[column]) - 1
                self.mappings[column][new_category] = max_idx
                self.mappings[column][self.unkown_token] = max_idx + 1
                # self.logger.info(
                #    f"New mapping added for category {new_category}.")
                return True
        return False

    def get_vocab_sizes(self) -> Dict[str, int]:
        return {col: len(mapping) for col, mapping in self.mappings.items()}
