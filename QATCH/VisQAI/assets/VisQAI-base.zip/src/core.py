# core.py - Consolidated core functionality for VisQAI
from typing import Dict, List, Tuple, Optional, Union
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import pickle
import warnings
from datetime import datetime
import json

# --- CONFIGURATION ---
BASE_CATEGORICAL = [
    'Protein_type', 'Protein_class_type', 'Buffer_type',
    'Salt_type', 'Stabilizer_type', 'Surfactant_type',
    'Excipient_type'
]

BASE_NUMERIC = [
    'MW', 'Protein_conc', 'Temperature', 'Buffer_pH',
    'Buffer_conc', 'Salt_conc', 'Stabilizer_conc',
    'Surfactant_conc', 'Excipient_conc',
    'kP', 'C_Class', 'HCI'
]

TARGETS = [
    'Viscosity_100', 'Viscosity_1000', 'Viscosity_10000',
    'Viscosity_100000', 'Viscosity_15000000'
]

# --- PHYSICS PRIORS ---

EXCIPIENT_PRIORS = {
    # (Protein_Class, Regime): {Excipient_Name: Effect_Value}

    # IgG1 [cite: 15]
    ('mab_igg1', 'near'): {'arginine': -2, 'lysine': -1, 'nacl': -1, 'proline': 0, 'sucrose': 1, 'tween': -1},
    ('mab_igg1', 'mixed'): {'arginine': -1, 'lysine': -1, 'nacl': -1, 'proline': -1, 'sucrose': 1, 'tween': -1},
    ('mab_igg1', 'far'): {'arginine': 0, 'lysine': -1, 'nacl': -1, 'proline': -1, 'sucrose': 1, 'tween': -1},

    # IgG4 [cite: 18]
    ('mab_igg4', 'near'): {'arginine': -2, 'lysine': -1, 'nacl': -1, 'proline': 0, 'sucrose': 1, 'tween': -1},
    ('mab_igg4', 'mixed'): {'arginine': -2, 'lysine': -1, 'nacl': -1, 'proline': -1, 'sucrose': 1, 'tween': -1},
    ('mab_igg4', 'far'): {'arginine': -1, 'lysine': -1, 'nacl': -1, 'proline': -1, 'sucrose': 1, 'tween': -1},

    # Fc-Fusion / Trispecific (linker-rich) [cite: 21]
    ('fc-fusion', 'near'): {'arginine': -1, 'lysine': -1, 'nacl': -1, 'proline': -1, 'sucrose': 1, 'tween': -2},
    ('fc-fusion', 'mixed'): {'arginine': -1, 'lysine': 0, 'nacl': 0, 'proline': -2, 'sucrose': 1, 'tween': -2},
    ('fc-fusion', 'far'): {'arginine': 0, 'lysine': 0, 'nacl': 0, 'proline': -2, 'sucrose': 1, 'tween': -2},

    # Bispecific / ADC [cite: 24]
    ('bispecific', 'near'): {'arginine': -2, 'lysine': -1, 'nacl': -1, 'proline': 0, 'sucrose': 1, 'tween': -1},
    ('bispecific', 'mixed'): {'arginine': -1, 'lysine': 0, 'nacl': 0, 'proline': -1, 'sucrose': 1, 'tween': -2},
    ('bispecific', 'far'): {'arginine': 0, 'lysine': 0, 'nacl': 0, 'proline': -1, 'sucrose': 1, 'tween': -2},

    # Fallback/Polyclonal [cite: 27]
    ('other', 'near'): {'arginine': -1, 'lysine': -1, 'nacl': -1, 'proline': 0, 'sucrose': 1, 'tween': 0},
    ('other', 'mixed'): {'arginine': 0, 'lysine': 0, 'nacl': 0, 'proline': -1, 'sucrose': 1, 'tween': 0},
    ('other', 'far'): {'arginine': 0, 'lysine': 0, 'nacl': 0, 'proline': -1, 'sucrose': 1, 'tween': 0},
}

# Map your specific column names to the generic types in the Prior Table
EXCIPIENT_TYPE_MAPPING = {
    'Salt_type': ['nacl'],
    'Excipient_type': ['arginine', 'lysine', 'proline'],
    'Stabilizer_type': ['sucrose'],
    'Surfactant_type': ['tween']
}

# --- DATA UTILITIES ---


def clean(df: pd.DataFrame,
          numeric_cols: List[str],
          categorical_cols: List[str],
          target_cols: Optional[List[str]] = None) -> pd.DataFrame:
    """
    Clean and preprocess dataframe.

    Args:
        df: Input dataframe
        numeric_cols: List of numeric column names
        categorical_cols: List of categorical column names
        target_cols: List of target column names (optional)

    Returns:
        Cleaned dataframe
    """
    df_clean = df.copy()
    bad_str = {"nan", "none", "null", "", "na", "n/a"}

    # Clean string columns
    for col in df_clean.columns:
        if df_clean[col].dtype == object:
            df_clean[col] = df_clean[col].astype(
                str).str.strip().str.lower().replace(bad_str, np.nan)

    # Separate concentration columns from physical property columns
    conc_cols = [c for c in numeric_cols if 'conc' in c.lower()]
    phys_cols = [c for c in numeric_cols if c not in conc_cols]

    # Convert to numeric
    for col in numeric_cols:
        df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')

    # Fill concentration columns with 0
    df_clean[conc_cols] = df_clean[conc_cols].fillna(0.0)

    # Fill physical property columns with median
    for col in phys_cols:
        if col in df_clean.columns:
            median_val = df_clean[col].median()
            if pd.isna(median_val):
                median_val = 0
            df_clean[col] = df_clean[col].fillna(median_val)

    # Fill categorical columns with "none"
    for col in categorical_cols:
        df_clean[col] = df_clean[col].replace({np.nan: "none"})

    # Clean target columns if provided
    if target_cols:
        for col in target_cols:
            df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
        df_clean = df_clean.dropna(subset=target_cols)
        for col in target_cols:
            df_clean = df_clean[df_clean[col] > 0]

    return df_clean


def validate_data(X_num: np.ndarray,
                  X_cat: np.ndarray,
                  y: np.ndarray,
                  name: str = "data") -> bool:
    """
    Validate data for NaN and Inf values.

    Args:
        X_num: Numeric features
        X_cat: Categorical features
        y: Target values
        name: Name for error messages

    Returns:
        True if validation passes

    Raises:
        ValueError: If data contains NaN or Inf values
    """
    if np.any(np.isnan(X_num)):
        raise ValueError(f"NaN in {name} numeric features")
    if np.any(np.isinf(X_num)):
        raise ValueError(f"Inf in {name} numeric features")
    if np.any(np.isnan(y)):
        raise ValueError(f"NaN in {name} targets")
    return True


def calculate_sample_weights(y_raw: np.ndarray) -> np.ndarray:
    """
    Calculate sample weights based on viscosity values.
    Emphasizes high viscosity samples which are rare but important.

    Args:
        y_raw: Raw target values (n_samples, n_targets)

    Returns:
        Sample weights (n_samples,)
    """
    v100 = y_raw[:, 0]  # Viscosity_100 is the first target

    # Base weight: Logarithmic (Standard)
    weights = 1.0 + np.log1p(v100)

    # Boost High Viscosity Samples
    # Samples > 20 cP are rare and exhibit exponential behavior.
    # We multiply their weight by 5.0 to force the model to fit the "hockey stick" curve.
    high_vis_mask = v100 > 20.0
    weights[high_vis_mask] *= 5.0

    return weights.astype(np.float32)


def log_transform_targets(y: np.ndarray) -> np.ndarray:
    """Transform targets to log space for training."""
    return np.log10(y + 1e-8)


def inverse_log_transform(y_log: np.ndarray) -> np.ndarray:
    """Transform targets back to linear space."""
    return 10 ** y_log - 1e-8


def compute_metrics(pred: np.ndarray, actual: np.ndarray) -> List[Dict[str, float]]:
    """Compute correlation and R² for each target."""
    metrics = []
    for i in range(pred.shape[1]):
        p, a = pred[:, i], actual[:, i]
        corr = np.corrcoef(p, a)[0, 1]
        r2 = 1 - np.sum((a - p)**2) / np.sum((a - a.mean())**2)
        metrics.append({'corr': corr, 'r2': r2})
    return metrics


def to_tensors(X_num: np.ndarray,
               X_cat: np.ndarray,
               y: Optional[np.ndarray] = None,
               weights: Optional[np.ndarray] = None) -> Tuple[torch.Tensor, ...]:
    """
    Convert numpy arrays to PyTorch tensors with strictly enforced types.

    Args:
        X_num: Numeric features (converted to Float32)
        X_cat: Categorical features (converted to Long/Int64)
        y: Target values (converted to Float32)
        weights: Sample weights (converted to Float32)

    Returns:
        Tuple of tensors matching the inputs provided.
    """
    tensors = [
        # Enforce Float32 for numeric inputs (prevents Double vs Float errors)
        torch.tensor(X_num, dtype=torch.float32),
        # Enforce Long (Int64) for categorical indices (required for nn.Embedding)
        torch.tensor(X_cat, dtype=torch.long)
    ]

    if y is not None:
        tensors.append(torch.tensor(y, dtype=torch.float32))

    if weights is not None:
        tensors.append(torch.tensor(weights, dtype=torch.float32))

    return tuple(tensors)


# --- MODEL COMPONENTS ---


class EmbeddingDropout(nn.Module):
    """Drop entire embedding vectors, not individual dimensions."""

    def __init__(self, p: float):
        super().__init__()
        self.p = p

    def forward(self, x):
        if not self.training or self.p == 0:
            return x
        mask = (torch.rand(x.size(0), 1, device=x.device) > self.p).float()
        return x * mask


class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout):
        super().__init__()
        self.fc = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.act = nn.ReLU()
        self.drop = nn.Dropout(dropout)

    def forward(self, x):
        residual = x
        x = self.fc(x)
        x = self.norm(x)
        x = self.act(x)
        x = self.drop(x)
        return x + residual


class Model(nn.Module):
    def __init__(
        self,
        cat_maps: Dict,
        numeric_dim: int,
        out_dim: int,
        hidden_sizes: List[int],
        dropout: float,
        residual: bool = True,
        emb_dropout: float = 0.05,
    ):
        super().__init__()
        self.cat_feature_names = list(cat_maps.keys())
        self.cat_maps = {k: list(v) for k, v in cat_maps.items()}

        # Helper indices
        try:
            self.p_class_idx = self.cat_feature_names.index(
                'Protein_class_type')
            # Ensure 'Regime' is passed in cat_maps. If it comes from DataProcessor, it should be there.
            self.regime_idx = self.cat_feature_names.index('Regime')
        except ValueError:
            print(
                "Warning: 'Protein_class_type' or 'Regime' not found in categorical maps.")
            print("Physics priors will not be applied correctly.")
            self.p_class_idx = -1
            self.regime_idx = -1

        self.embeddings = nn.ModuleList()
        self.prior_lookups = []  # To store tensors for physics lookup

        self.emb_drop = EmbeddingDropout(emb_dropout)

        # Initialize Embeddings
        for col in self.cat_feature_names:
            vocab = len(self.cat_maps[col])
            emb_dim = min(32, max(4, int(vocab ** 0.5 * 2)))

            # Standard Embedding
            emb_layer = nn.Embedding(vocab, emb_dim)
            self.embeddings.append(emb_layer)

            # Check if this column is an Excipient column needing physics priors
            prior_tensor = None
            if self.p_class_idx != -1 and col in EXCIPIENT_TYPE_MAPPING:
                prior_tensor = self._build_prior_tensor(col)

            self.prior_lookups.append(prior_tensor)

        total_emb_dim = sum(e.embedding_dim for e in self.embeddings)
        total_in = total_emb_dim + numeric_dim

        self.regime_gate = None
        if self.regime_idx != -1:
            num_regimes = len(self.cat_maps['Regime'])
            # Output dim is 1 (a scalar multiplier)
            self.regime_gate = nn.Embedding(num_regimes, 1)

            # Initialize to 1.0 so we start neutral
            nn.init.constant_(self.regime_gate.weight, 1.0)

        # Encoder Network
        layers = []
        prev = total_in
        for h in hidden_sizes:
            layers.append(nn.Linear(prev, h))
            layers.append(nn.LayerNorm(h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev = h
        self.base = nn.Sequential(*layers)

        # Residual Blocks
        self.residual_blocks = nn.ModuleList()
        self.use_residual = residual
        if residual:
            for h in hidden_sizes:
                self.residual_blocks.append(ResidualBlock(h, dropout))

        # Output Heads
        self.heads = nn.ModuleList([nn.Linear(prev, 1)
                                   for _ in range(out_dim)])
        self.apply(self._init_weights)

    def _build_prior_tensor(self, col_name: str) -> torch.Tensor:
        """
        Pre-computes a 3D tensor of shape (n_classes, n_regimes, n_excipients)
        containing the Table C prior values.
        """
        p_classes = self.cat_maps['Protein_class_type']
        regimes = self.cat_maps['Regime']
        excipients = self.cat_maps[col_name]

        # Initialize with zeros
        prior_tensor = torch.zeros(
            len(p_classes), len(regimes), len(excipients))

        for p_i, p_val in enumerate(p_classes):
            for r_i, r_val in enumerate(regimes):
                for e_i, e_val in enumerate(excipients):
                    # Normalize strings for lookup
                    p_key = p_val.lower()
                    r_key = r_val.lower()
                    e_key = e_val.lower()

                    # Find matching prior
                    # 1. Get the specific prior dict for this class/regime
                    prior_dict = EXCIPIENT_PRIORS.get(
                        (p_key, r_key), None)
                    if prior_dict is None:
                        # Try fallback to 'other'
                        prior_dict = EXCIPIENT_PRIORS.get(
                            ('other', r_key), {})

                    # 2. Look up the effect of this excipient
                    effect = prior_dict.get(e_key, 0)
                    prior_tensor[p_i, r_i, e_i] = effect

        return prior_tensor

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)

    def forward(self, x_num, x_cat, return_features=False):
        # Process embeddings
        emb_list = []
        for i, emb_layer in enumerate(self.embeddings):
            e = emb_layer(x_cat[:, i])
            emb_list.append(e)

        emb_cat = torch.cat(emb_list, dim=1)
        emb_cat = self.emb_drop(emb_cat)

        # Concatenate numeric and categorical features
        x = torch.cat([emb_cat, x_num], dim=1)

        # Encoder
        x = self.base(x)

        # Residual blocks
        if self.use_residual:
            for block in self.residual_blocks:
                x = block(x)

        if return_features:
            features = x.clone()

        # Output heads
        outputs = []
        for head in self.heads:
            out = head(x)
            outputs.append(out)
        y_pred = torch.cat(outputs, dim=1)

        # Physics priors
        if self.p_class_idx != -1:
            prior_correction = self._get_prior_correction(x_cat)
            y_pred = y_pred + prior_correction

        # Regime gate
        if self.regime_gate is not None and self.regime_idx != -1:
            gate = self.regime_gate(x_cat[:, self.regime_idx])
            gate = torch.sigmoid(gate)
            y_pred = y_pred * gate

        if return_features:
            return y_pred, features
        return y_pred

    def _get_prior_correction(self, x_cat):
        """
        Compute the sum of all excipient priors for each sample in the batch.
        """
        batch_size = x_cat.size(0)
        device = x_cat.device
        prior_effects = torch.zeros(
            batch_size, device=device, dtype=torch.float32)

        # Protein class and regime indices
        p_class_indices = x_cat[:, self.p_class_idx]
        regime_indices = x_cat[:, self.regime_idx]

        # Loop over all excipient columns
        for col_i, col_name in enumerate(self.cat_feature_names):
            prior_tensor = self.prior_lookups[col_i]
            if prior_tensor is not None:
                prior_tensor = prior_tensor.to(device)
                excipient_indices = x_cat[:, col_i]

                # For each sample, look up (p_class, regime, excipient) -> effect
                for i in range(batch_size):
                    p = p_class_indices[i].item()
                    r = regime_indices[i].item()
                    e = excipient_indices[i].item()

                    if 0 <= p < prior_tensor.size(0) and 0 <= r < prior_tensor.size(1) and 0 <= e < prior_tensor.size(2):
                        effect = prior_tensor[p, r, e]
                        # Only apply if excipient is present (index != 0, assuming 0 = 'none')
                        if e != 0:
                            prior_effects[i] += effect

        return prior_effects.reshape(-1, 1)

    def expand_categorical_embedding(
        self,
        feature_name: str,
        new_categories: List[str],
        initialization: str = 'mean'
    ) -> None:
        """
        Expand an embedding layer to accommodate new categories.
        """
        if feature_name not in self.cat_feature_names:
            raise ValueError(
                f"Feature {feature_name} not in categorical features")

        idx = self.cat_feature_names.index(feature_name)
        old_emb = self.embeddings[idx]
        old_vocab_size = len(self.cat_maps[feature_name])
        new_vocab_size = old_vocab_size + len(new_categories)

        # Create new embedding
        new_emb = nn.Embedding(new_vocab_size, old_emb.embedding_dim)

        # Copy old weights
        with torch.no_grad():
            new_emb.weight[:old_vocab_size] = old_emb.weight

            # Initialize new embeddings
            if initialization == 'mean':
                mean_embedding = old_emb.weight.mean(dim=0)
                for i in range(len(new_categories)):
                    new_emb.weight[old_vocab_size +
                                   i] = mean_embedding + torch.randn_like(mean_embedding) * 0.01
            elif initialization == 'zero':
                new_emb.weight[old_vocab_size:] = 0.0

        # Replace embedding
        self.embeddings[idx] = new_emb

        # Update cat_maps
        self.cat_maps[feature_name].extend(new_categories)

        print(
            f"Expanded {feature_name} from {old_vocab_size} to {new_vocab_size} categories")


class EnsembleModel(nn.Module):
    """Ensemble wrapper for multiple models with uncertainty quantification."""

    def __init__(self, models: List[nn.Module]):
        super().__init__()
        self.models = nn.ModuleList(models)

    @property
    def cat_maps(self) -> Dict:
        """Proxy to first model's cat_maps for consistent interface."""
        return self.models[0].cat_maps

    @property
    def cat_feature_names(self) -> List[str]:
        """Proxy to first model's cat_feature_names for consistent interface."""
        return self.models[0].cat_feature_names

    @property
    def embeddings(self) -> nn.ModuleList:
        """Proxy to first model's embeddings for consistent interface."""
        return self.models[0].embeddings

    def forward(self, x_num, x_cat):
        """Forward pass returning mean prediction."""
        outputs = [model(x_num, x_cat) for model in self.models]
        return torch.stack(outputs).mean(dim=0)

    def get_individual_predictions(self, x_num, x_cat):
        """Get predictions from each model individually for uncertainty estimation."""
        with torch.no_grad():
            outputs = [model(x_num, x_cat) for model in self.models]
        return torch.stack(outputs)  # (n_models, batch_size, n_targets)

    def expand_categorical_embedding(
        self,
        feature_name: str,
        new_categories: List[str],
        initialization: str = 'mean'
    ) -> None:
        """Expand embeddings on all models in the ensemble."""
        for model in self.models:
            model.expand_categorical_embedding(
                feature_name, new_categories, initialization)


# --- PHYSICS-INFORMED LOSS ---


def get_physics_masks(X_cat: torch.Tensor,
                      X_num: torch.Tensor,
                      processor: 'DataProcessor') -> Dict[str, torch.Tensor]:
    """
    Generate boolean masks for physics constraints based on batch data.

    Args:
        X_cat: Tensor of categorical indices (batch, n_cat)
        X_num: Tensor of numeric features (batch, n_num).
               NOTE: If this is scaled data, the HCI check >= 1.3 might be checking Z-scores!
        processor: Fitted DataProcessor instance

    Returns:
        Dictionary of masks for physics constraints
    """
    masks = {}
    device = X_cat.device

    try:
        # 1. Regime mask (Near or Mixed)
        if 'Regime' in processor.categorical_features:
            idx_regime = processor.categorical_features.index('Regime')
            regime_map = processor.cat_maps['Regime']

            # Find indices for 'near' and 'mixed' in the vocabulary
            near_idx = [i for i, x in enumerate(
                regime_map) if 'near' in x.lower()]
            mixed_idx = [i for i, x in enumerate(
                regime_map) if 'mixed' in x.lower()]

            target_regimes = torch.tensor(near_idx + mixed_idx, device=device)

            # Mask: Is Near or Mixed?
            masks['is_near_mixed'] = torch.isin(
                X_cat[:, idx_regime], target_regimes).float().unsqueeze(1)
        else:
            masks['is_near_mixed'] = torch.zeros(
                X_cat.shape[0], 1, device=device)

        # 2. Mask: High HCI? (HCI >= 1.3)
        if 'HCI' in processor.numeric_features:
            hci_idx = processor.numeric_features.index('HCI')

            # CRITICAL NOTE: X_num is likely SCALED (StandardScaler).
            # Checking >= 1.3 here implies Z-score >= 1.3, not absolute HCI >= 1.3.
            masks['is_high_hci'] = (
                X_num[:, hci_idx] >= 1.3).float().unsqueeze(1)
        else:
            masks['is_high_hci'] = torch.zeros(
                X_cat.shape[0], 1, device=device)

        # 3. Placeholder Masks for Excipients
        # (Could be expanded to check actual presence of excipients)
        masks['has_ionic'] = torch.ones(X_cat.shape[0], 1, device=device)
        masks['has_sucrose'] = torch.ones(X_cat.shape[0], 1, device=device)
        masks['has_tween'] = torch.ones(X_cat.shape[0], 1, device=device)

    except Exception as e:
        print(f"Warning: Could not build physics masks: {e}")
        # Fallback to zeros
        return {k: torch.zeros(X_cat.shape[0], 1, device=device)
                for k in ['is_near_mixed', 'is_high_hci', 'has_ionic', 'has_sucrose', 'has_tween']}

    return masks


class PhysicsInformedLoss(nn.Module):
    """
    Physics-informed loss function incorporating domain knowledge constraints.

    Combines:
    1. Standard MSE loss
    2. Shear-thinning constraint (viscosity should decrease with shear rate)
    3. Input gradient constraints from domain knowledge
    """

    def __init__(self, lambda_shear: float = 1.0, lambda_input: float = 0.1,
                 numeric_cols: Optional[List[str]] = None):
        """
        Args:
            lambda_shear: Weight for shear-thinning constraint (output consistency).
            lambda_input: Weight for input-gradient constraints (Table D rules).
            numeric_cols: List of numeric column names to identify indices.
        """
        super().__init__()
        self.lambda_shear = lambda_shear
        self.lambda_input = lambda_input
        self.numeric_cols = numeric_cols or []

        # Pre-calculate indices for numeric features if possible
        self.idx_map = {name: i for i, name in enumerate(self.numeric_cols)}

    def forward(self, pred: torch.Tensor, target: torch.Tensor,
                inputs_num: torch.Tensor, masks: Dict[str, torch.Tensor],
                weights: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Args:
            pred: Model outputs (batch, n_targets)
            target: True targets
            inputs_num: Numeric inputs (batch, n_features). MUST have requires_grad=True.
            masks: Dictionary containing boolean masks for the batch:
                   - 'is_near_mixed': (batch, 1) 1 if Regime is Near/Mixed
                   - 'is_high_hci': (batch, 1) 1 if HCI >= 1.3
                   - 'has_ionic': (batch, 1) 1 if Salt/Arg/Lys present
                   - 'has_sucrose': (batch, 1) 1 if Sucrose present
                   - 'has_tween': (batch, 1) 1 if Tween present
            weights: Sample weights
        """
        # 1. Standard MSE Loss
        squared_diff = (pred - target) ** 2
        if weights is not None:
            if weights.dim() == 1:
                weights = weights.unsqueeze(1)
            mse_loss = (squared_diff * weights).mean()
        else:
            mse_loss = squared_diff.mean()

        # 2. Shear Thinning Constraint (Output Monotonicity)
        # Viscosity should decrease (or stay same) as shear rate increases (next column)
        shear_loss = 0.0
        for i in range(pred.shape[1] - 1):
            # diff > 0 means Viscosity(High Shear) > Viscosity(Low Shear) -> Violation
            diff = pred[:, i+1] - pred[:, i]
            violation = torch.relu(diff)
            shear_loss += violation.mean()

        # 3. Input Gradient Constraints (Table D from PDF)
        input_loss = 0.0

        # We need gradients of predictions w.r.t inputs to check sensitivity
        if self.lambda_input > 0 and inputs_num.requires_grad:
            # Calculate Gradients
            grads = torch.autograd.grad(
                outputs=pred.sum(),
                inputs=inputs_num,
                create_graph=True,
                retain_graph=True,
                only_inputs=True,
                allow_unused=True
            )[0]

            # If inputs weren't used in the graph, grads will be None.
            if grads is not None:
                # Constraint A: Ionic Strength
                if 'Salt_conc' in self.idx_map and 'Excipient_conc' in self.idx_map:
                    idx_s = self.idx_map['Salt_conc']
                    idx_e = self.idx_map['Excipient_conc']
                    grad_ionic = grads[:, idx_s] + grads[:, idx_e]
                    mask_a = masks.get('is_near_mixed', 0) * \
                        masks.get('has_ionic', 0)
                    input_loss += (torch.relu(grad_ionic) * mask_a).mean()

                # Constraint B: Sucrose
                if 'Stabilizer_conc' in self.idx_map:
                    idx_suc = self.idx_map['Stabilizer_conc']
                    grad_suc = grads[:, idx_suc]
                    mask_b = masks.get('has_sucrose', 0)
                    input_loss += (torch.relu(-grad_suc) * mask_b).mean()

                # Constraint C: Tween
                if 'Surfactant_conc' in self.idx_map:
                    idx_tw = self.idx_map['Surfactant_conc']
                    grad_tw = grads[:, idx_tw]
                    mask_c = masks.get('is_high_hci', 0) * \
                        masks.get('has_tween', 0)
                    input_loss += (torch.relu(grad_tw) * mask_c).mean()

        total_loss = mse_loss + (self.lambda_shear *
                                 shear_loss) + (self.lambda_input * input_loss)
        return total_loss


# --- DATA PROCESSOR ---


class DataProcessor:
    """
    Handles all data preprocessing including:
    - Categorical encoding with vocabulary mapping
    - Numeric feature scaling
    - Feature engineering (e.g., Regime computation)
    - Distance-based trust scores
    """

    def __init__(self, allow_new_categories: bool = False):
        self.cat_maps = {}
        self.scaler = StandardScaler()
        self.is_fitted = False
        self.categorical_features = BASE_CATEGORICAL.copy()
        self.numeric_features = BASE_NUMERIC.copy()
        self.allow_new_categories = allow_new_categories
        self.constant_features = []
        self.constant_values = {}
        self.scalable_features = []

    def _compute_regime(self, df: pd.DataFrame) -> pd.Series:
        """Compute interaction regime based on kP and C values."""
        if 'kP' not in df.columns or 'C_Class' not in df.columns:
            return pd.Series(['unknown'] * len(df), index=df.index)

        kp = df['kP'].values
        c = df['C_Class'].values

        regime = []
        for i in range(len(df)):
            if pd.isna(kp[i]) or pd.isna(c[i]):
                regime.append('unknown')
            elif kp[i] < 1:
                regime.append('far')
            elif 1 <= kp[i] < 1.25:
                regime.append('mixed')
            elif kp[i] >= 1.25:
                regime.append('near')
            else:
                regime.append('unknown')

        return pd.Series(regime, index=df.index)

    def _fit_categorical(self, df: pd.DataFrame) -> None:
        """Build categorical vocabularies."""
        for col in self.categorical_features:
            if col not in df.columns:
                print(f"Warning: {col} not in dataframe, skipping")
                continue

            unique_vals = df[col].dropna().unique().tolist()
            if 'none' not in unique_vals:
                unique_vals.insert(0, 'none')

            self.cat_maps[col] = unique_vals

        # Add Regime as a categorical feature if not already present
        if 'Regime' not in self.categorical_features:
            self.categorical_features.append('Regime')
            self.cat_maps['Regime'] = ['far', 'mixed', 'near', 'unknown']

    def _transform_categorical(self, df: pd.DataFrame) -> np.ndarray:
        """Transform categorical features to indices."""
        cat_data = []
        for col in self.categorical_features:
            if col == 'Regime':
                # Compute regime on-the-fly
                regime_vals = self._compute_regime(df)
                indices = [self.cat_maps['Regime'].index(
                    val) if val in self.cat_maps['Regime'] else 0
                    for val in regime_vals]
            else:
                if col not in df.columns:
                    # Fill with 'none' if column is missing
                    indices = [0] * len(df)
                else:
                    values = df[col].fillna('none').astype(str).str.lower()
                    indices = []
                    for val in values:
                        if val in self.cat_maps[col]:
                            indices.append(self.cat_maps[col].index(val))
                        else:
                            if self.allow_new_categories:
                                # Add new category
                                self.cat_maps[col].append(val)
                                indices.append(len(self.cat_maps[col]) - 1)
                            else:
                                # Map to 'none'
                                indices.append(0)

            cat_data.append(indices)

        return np.array(cat_data, dtype=np.int64).T

    def fit_transform(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Fit processor and transform data."""
        self._fit_categorical(df)

        # Identify constant features
        for col in self.numeric_features:
            if col in df.columns:
                unique_vals = df[col].dropna().unique()
                if len(unique_vals) == 1:
                    self.constant_features.append(col)
                    self.constant_values[col] = unique_vals[0]

        # Features to scale (non-constant numeric features)
        self.scalable_features = [
            col for col in self.numeric_features
            if col not in self.constant_features and col in df.columns
        ]

        # Fit scaler on scalable features
        if self.scalable_features:
            X_scalable = df[self.scalable_features].values
            self.scaler.fit(X_scalable)

        self.is_fitted = True
        return self.transform(df)

    def transform(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Transform data using fitted processor."""
        if not self.is_fitted:
            raise ValueError("Processor must be fitted first")

        X_cat = self._transform_categorical(df)

        # Build numeric array
        X_num_list = []
        for col in self.numeric_features:
            if col in self.constant_features:
                # Use constant value
                X_num_list.append(
                    np.full(len(df), self.constant_values[col]))
            elif col in self.scalable_features:
                # Will be scaled below
                if col in df.columns:
                    X_num_list.append(df[col].values)
                else:
                    X_num_list.append(np.zeros(len(df)))
            else:
                # Feature not in df or not scalable
                X_num_list.append(np.zeros(len(df)))

        X_num = np.column_stack(X_num_list)

        # Apply scaling to scalable features
        if self.scalable_features:
            scalable_indices = [
                i for i, col in enumerate(self.numeric_features)
                if col in self.scalable_features
            ]
            X_num[:, scalable_indices] = self.scaler.transform(
                X_num[:, scalable_indices]
            )

        return X_num, X_cat

    def compute_distance(self, X_num: np.ndarray) -> np.ndarray:
        """
        Compute trust distance for samples based on training data distribution.
        Uses Mahalanobis-inspired distance metric.
        """
        if not hasattr(self.scaler, 'mean_') or self.scaler.mean_ is None:
            # No scaler fitted, return zeros
            return np.zeros(X_num.shape[0])

        # Compute scaled distance from training mean
        # Since data is already scaled, this is essentially L2 distance in standardized space
        distances = np.linalg.norm(X_num, axis=1)
        return distances

    def detect_new_categories(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """Detect categories that weren't seen during fitting."""
        new_cats = {}
        for col in self.categorical_features:
            if col == 'Regime' or col not in df.columns:
                continue

            df_vals = set(df[col].dropna().astype(
                str).str.lower().unique())
            known_vals = set(self.cat_maps[col])
            unseen = df_vals - known_vals

            if unseen:
                new_cats[col] = list(unseen)

        return new_cats

    def add_categories(self, feature_name: str, new_categories: List[str]) -> None:
        """Add new categories to vocabulary."""
        if feature_name not in self.cat_maps:
            raise ValueError(f"Feature {feature_name} not found")

        for cat in new_categories:
            if cat not in self.cat_maps[feature_name]:
                self.cat_maps[feature_name].append(cat)

        print(f"Added {len(new_categories)} categories to {feature_name}")

    def _get_prior_correction(self, x_cat):
        """
        Compute the sum of all excipient priors for each sample.
        """
        batch_size = x_cat.size(0)
        device = x_cat.device
        prior_effects = torch.zeros(
            batch_size, device=device, dtype=torch.float32)

        # Find protein class and regime indices
        try:
            p_class_idx = self.categorical_features.index('Protein_class_type')
            regime_idx = self.categorical_features.index('Regime')
        except ValueError:
            return prior_effects.reshape(-1, 1)

        p_class_indices = x_cat[:, p_class_idx]
        regime_indices = x_cat[:, regime_idx]

        # Loop over excipient columns
        for col_i, col_name in enumerate(self.categorical_features):
            if col_name not in EXCIPIENT_TYPE_MAPPING:
                continue

            excipient_indices = x_cat[:, col_i]
            excipient_map = self.cat_maps[col_name]

            for i in range(batch_size):
                p_class_str = self.cat_maps['Protein_class_type'][p_class_indices[i].item(
                )].lower()
                regime_str = self.cat_maps['Regime'][regime_indices[i].item(
                )].lower()
                excipient_idx = excipient_indices[i].item()

                if excipient_idx == 0:  # 'none'
                    continue

                excipient_str = excipient_map[excipient_idx].lower()

                # Look up prior
                prior_dict = EXCIPIENT_PRIORS.get((p_class_str, regime_str))
                if prior_dict is None:
                    prior_dict = EXCIPIENT_PRIORS.get(
                        ('other', regime_str), {})

                for exc_type in EXCIPIENT_TYPE_MAPPING[col_name]:
                    if exc_type in excipient_str:
                        effect = prior_dict.get(exc_type, 0)
                        if effect != 0:
                            prior_effects[i] += effect

        return prior_effects.reshape(-1, 1)

    def get_vocab_sizes(self) -> Dict[str, int]:
        if not self.is_fitted:
            raise ValueError("Processor must be fitted first")
        return {col: len(self.cat_maps[col]) for col in self.categorical_features}

    def save(self, path: str) -> None:
        state = {
            'cat_maps': self.cat_maps,
            'scaler': self.scaler,
            'is_fitted': self.is_fitted,
            'categorical_features': self.categorical_features,
            'numeric_features': self.numeric_features,
            'allow_new_categories': self.allow_new_categories,
            'constant_features': self.constant_features,
            'constant_values': self.constant_values,
            'scalable_features': self.scalable_features,
        }
        with open(path, 'wb') as f:
            pickle.dump(state, f)

    def load(self, path: str) -> None:
        with open(path, 'rb') as f:
            state = pickle.load(f)

        self.cat_maps = state['cat_maps']
        self.scaler = state['scaler']
        self.is_fitted = state['is_fitted']
        self.categorical_features = state.get(
            'categorical_features', BASE_CATEGORICAL.copy())
        self.numeric_features = state.get(
            'numeric_features', BASE_NUMERIC.copy())
        self.allow_new_categories = state.get('allow_new_categories', False)
        self.constant_features = state.get('constant_features', [])
        self.constant_values = state.get('constant_values', {})
        self.scalable_features = state.get(
            'scalable_features', self.numeric_features.copy())


# --- MODEL EVALUATION ---


def evaluate_model(model: nn.Module,
                   processor: DataProcessor,
                   data_path: str,
                   output_prefix: str = 'evaluation') -> Dict:
    """
    Comprehensive model evaluation with metrics and predictions.

    Args:
        model: Trained model (can be single or ensemble)
        processor: Fitted data processor
        data_path: Path to evaluation data CSV
        output_prefix: Prefix for output files

    Returns:
        Dictionary containing evaluation metrics
    """
    print("\n" + "=" * 70)
    print("Model Evaluation on Full Dataset")
    print("=" * 70)

    df = pd.read_csv(data_path)
    df_clean = clean(
        df,
        numeric_cols=BASE_NUMERIC,
        categorical_cols=BASE_CATEGORICAL,
        target_cols=TARGETS
    )

    print(f"\nEvaluating on {len(df_clean)} samples")
    X_num, X_cat = processor.transform(df_clean)

    # Calculate Trust Distance
    trust_distances = processor.compute_distance(X_num)

    y_true = df_clean[TARGETS].values
    y_log = log_transform_targets(y_true)

    X_num_t, X_cat_t, y_log_t = to_tensors(X_num, X_cat, y_log)

    model.eval()
    with torch.no_grad():
        y_log_pred = model(X_num_t, X_cat_t).numpy()
    y_pred = inverse_log_transform(y_log_pred)

    # Compute metrics
    metrics = {}
    print("\nPer-Target Metrics:")
    print("-" * 70)

    for i, target_name in enumerate(TARGETS):
        y_true_target = y_true[:, i]
        y_pred_target = y_pred[:, i]

        mse = mean_squared_error(y_true_target, y_pred_target)
        rmse = np.sqrt(mse)
        mae = mean_absolute_error(y_true_target, y_pred_target)
        r2 = r2_score(y_true_target, y_pred_target)

        mask = y_true_target != 0
        if mask.sum() > 0:
            mape = np.mean(
                np.abs((y_true_target[mask] - y_pred_target[mask]) / y_true_target[mask])) * 100
        else:
            mape = np.nan

        metrics[target_name] = {
            'MSE': mse, 'RMSE': rmse, 'MAE': mae, 'R2': r2, 'MAPE': mape
        }

        print(f"\n{target_name}:")
        print(f"  MSE:  {mse:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  MAE:  {mae:.4f}")
        print(f"  R²:   {r2:.4f}")
        if not np.isnan(mape):
            print(f"  MAPE: {mape:.2f}%")

    print("\nOverall Metrics (averaged across targets):")
    print("-" * 70)
    overall_metrics = {
        'MSE': np.mean([m['MSE'] for m in metrics.values()]),
        'RMSE': np.mean([m['RMSE'] for m in metrics.values()]),
        'MAE': np.mean([m['MAE'] for m in metrics.values()]),
        'R2': np.mean([m['R2'] for m in metrics.values()]),
        'MAPE': np.nanmean([m['MAPE'] for m in metrics.values()])
    }

    for metric_name, value in overall_metrics.items():
        if metric_name == 'MAPE':
            print(f"  {metric_name}: {value:.2f}%")
        else:
            print(f"  {metric_name}: {value:.4f}")

    # Save detailed results
    results_df = df_clean.copy()
    results_df['Trust_Distance'] = trust_distances

    for i, target_name in enumerate(TARGETS):
        results_df[f'{target_name}_actual'] = y_true[:, i]
        results_df[f'{target_name}_predicted'] = y_pred[:, i]
        results_df[f'{target_name}_error'] = y_true[:, i] - y_pred[:, i]

        mask = y_true[:, i] != 0
        pct_error = np.zeros(len(y_true))
        pct_error[mask] = (y_true[:, i][mask] - y_pred[:, i]
                           [mask]) / y_true[:, i][mask] * 100
        results_df[f'{target_name}_pct_error'] = pct_error

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = f'{output_prefix}_predictions_{timestamp}.csv'
    results_df.to_csv(results_file, index=False)
    print(f"\nSaved predictions to: {results_file}")

    metrics_file = f'{output_prefix}_metrics_{timestamp}.json'
    all_metrics = {
        'per_target': metrics,
        'overall': overall_metrics,
        'n_samples': len(df_clean)
    }
    with open(metrics_file, 'w') as f:
        json.dump(all_metrics, f, indent=2)
    print(f"Saved metrics to: {metrics_file}")

    return all_metrics


# --- MODEL MANAGEMENT ---


def expand_processor_and_model(processor: DataProcessor,
                               model: Model,
                               feature_name: str,
                               new_categories: List[str],
                               initialization: str = 'mean') -> None:
    """Expand both processor and model for new categories."""
    processor.add_categories(feature_name, new_categories)
    model.expand_categorical_embedding(
        feature_name, new_categories, initialization)


class ResidualAdapter(nn.Module):
    """
    Residual Adapter network for domain adaptation.
    Added to core.py to ensure availability across modules.
    """

    def __init__(self, numeric_dim, cat_dims, embed_dim=16):
        super().__init__()
        self.num_proj = nn.Linear(numeric_dim, embed_dim)
        self.embeddings = nn.ModuleList([
            nn.Embedding(n, embed_dim) for n in cat_dims
        ])
        # Output dim is len(TARGETS) imported from config section above
        self.net = nn.Sequential(
            nn.Linear(embed_dim * (len(cat_dims) + 1), 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, len(TARGETS))
        )

    def forward(self, x_num, x_cat):
        embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
        num_emb = self.num_proj(x_num)
        x = torch.cat(embs + [num_emb], dim=1)
        return self.net(x)


def attach_adapter(model: Model, adapter_state_dict: Dict) -> nn.Module:
    """
    Reconstructs an adapter, loads its state, and attaches it to the model.
    Returns the adapter instance.
    """
    # 1. Inspect model to determine dimensions
    cat_dims = [len(m) for m in model.cat_maps.values()]
    # Estimate numeric dim: total input - embedding dims (approximate but effective for reconstruction)
    # Better: use the stored numeric_features count if available, but here we infer or rely on Model.
    # We assume model.base[0] is Linear(total_in, hidden).
    total_in = model.base[0].in_features
    total_emb = sum(e.embedding_dim for e in model.embeddings)
    numeric_dim = total_in - total_emb

    # 2. Initialize Adapter
    adapter = ResidualAdapter(numeric_dim, cat_dims, embed_dim=16)
    adapter.load_state_dict(adapter_state_dict)

    # 3. Attach Logic (Monkey Patch)
    adapter.eval()

    # Find Protein_type index for gating
    try:
        p_col_idx = model.cat_feature_names.index('Protein_type')
    except ValueError:
        p_col_idx = 0

    # The new category is typically the last one added
    new_p_idx = len(model.cat_maps['Protein_type']) - 1

    original_forward = model.forward

    # Check if already patched
    if hasattr(original_forward, '__name__') and original_forward.__name__ == 'new_forward':
        print("  [Core] Model already patched with adapter.")
        return adapter

    def new_forward(x_n, x_c, return_features=False):
        if return_features:
            base, feats = original_forward(x_n, x_c, return_features=True)
        else:
            base = original_forward(x_n, x_c)

        # Calculate residual
        adapt = adapter(x_n, x_c)

        # Gate: Only activate for the specific protein index
        mask = (x_c[:, p_col_idx] == new_p_idx).float().unsqueeze(1)

        res = base + (adapt * mask)

        if return_features:
            return res, feats
        return res

    model.forward = new_forward
    print("  [Core] Adapter successfully attached to Model forward pass.")

    return adapter

# --- MODEL MANAGEMENT ---


def save_model_checkpoint(model: nn.Module,
                          processor: DataProcessor,
                          best_params: Dict,
                          filepath: str,
                          adapter: Optional[nn.Module] = None) -> None:
    """
    Save model checkpoint with processor state, hyperparameters, and optional adapter.
    """
    checkpoint = {
        'model_state_dict': model.state_dict(),
        'best_params': best_params,
        'cat_maps': processor.cat_maps,
        'numeric_features': processor.numeric_features,
        'categorical_features': processor.categorical_features,
        'scaler_state': {
            'mean_': processor.scaler.mean_,
            'scale_': processor.scaler.scale_,
            'n_features_in_': getattr(processor.scaler, 'n_features_in_', 0)
        },
        'constant_values': processor.constant_values,
        'scalable_features': processor.scalable_features
    }

    # --- SAVE ADAPTER STATE ---
    if adapter is not None:
        checkpoint['adapter_state_dict'] = adapter.state_dict()
        checkpoint['has_adapter'] = True
    else:
        # Check if the model itself has a detached state dict stored
        if hasattr(model, 'adapter_state_dict') and model.adapter_state_dict is not None:
            checkpoint['adapter_state_dict'] = model.adapter_state_dict
            checkpoint['has_adapter'] = True
        else:
            checkpoint['has_adapter'] = False

    torch.save(checkpoint, filepath)
    print(
        f"Saved checkpoint to: {filepath} (Adapter saved: {checkpoint['has_adapter']})")


def load_model_checkpoint(filepath: str, device: str = "cpu") -> Tuple[Model, DataProcessor, Dict]:
    """
    Load model checkpoint. Attaches adapter_state_dict to model if present.
    """
    checkpoint = torch.load(filepath, map_location=device, weights_only=False)

    # Reconstruct processor
    processor = DataProcessor()
    processor.cat_maps = checkpoint.get("cat_maps", {})
    processor.numeric_features = checkpoint.get("numeric_features", [])
    processor.categorical_features = checkpoint.get("categorical_features", [])
    processor.constant_values = checkpoint.get("constant_values", {})
    processor.scalable_features = checkpoint.get(
        "scalable_features",
        processor.numeric_features.copy()
    )
    processor.constant_features = list(processor.constant_values.keys())
    processor.allow_new_categories = False
    processor.is_fitted = True

    # Rebuild scaler
    scaler_state = checkpoint.get("scaler_state", None)
    if scaler_state is not None:
        processor.scaler = StandardScaler()
        processor.scaler.mean_ = np.asarray(
            scaler_state["mean_"], dtype=np.float64)
        processor.scaler.scale_ = np.asarray(
            scaler_state["scale_"], dtype=np.float64)
        processor.scaler.n_features_in_ = int(scaler_state["n_features_in_"])
        if "feature_names_in_" in scaler_state:
            processor.scaler.feature_names_in_ = np.array(
                scaler_state["feature_names_in_"])
    else:
        processor.scaler = None

    # Reconstruct model
    best_params = checkpoint["best_params"]
    hidden_size = best_params["hidden_size"]
    n_layers = best_params["n_layers"]
    hidden_sizes = [hidden_size] * n_layers

    model = Model(
        cat_maps=processor.cat_maps,
        numeric_dim=len(processor.numeric_features),
        out_dim=len(TARGETS),
        hidden_sizes=hidden_sizes,
        dropout=best_params["dropout"],
    )

    # Handle Ensemble Keys
    state_dict = checkpoint["model_state_dict"]
    first_key = next(iter(state_dict.keys()))
    if first_key.startswith("models."):
        print(
            "  [INFO] Detected Ensemble checkpoint. Extracting weights for single Model...")
        new_state_dict = {}
        for k, v in state_dict.items():
            if k.startswith("models.0."):
                new_key = k.replace("models.0.", "")
                new_state_dict[new_key] = v
        state_dict = new_state_dict

    model.load_state_dict(state_dict)
    model.to(device)

    # Attach adapter state dict to model for downstream use
    if 'adapter_state_dict' in checkpoint:
        model.adapter_state_dict = checkpoint['adapter_state_dict']
        print(
            f"  [INFO] Adapter state found and attached to model.adapter_state_dict")
    else:
        model.adapter_state_dict = None

    print(f"Loaded checkpoint from: {filepath}")

    return model, processor, best_params
