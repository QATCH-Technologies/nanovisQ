"""
inference.py - Unified Inference and Adaptive Learning Module for VisQAI

Combines inference, uncertainty estimation, and Gated Adapter learning
into a single ViscosityPredictor class.
"""

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
import os
import glob
import warnings
from typing import Dict, List, Optional, Tuple, Union
from pathlib import Path

# Import core functionality
from core import (
    DataProcessor, Model, PhysicsInformedLoss, TARGETS,
    load_model_checkpoint, save_model_checkpoint,
    expand_processor_and_model, to_tensors,
    log_transform_targets, inverse_log_transform,
    EnsembleModel, BASE_NUMERIC, BASE_CATEGORICAL, clean
)

# --- 1. RESIDUAL ADAPTER MODULE ---


class ResidualAdapter(nn.Module):
    """
    A lightweight network that learns corrections to the base model's predictions.
    It runs in parallel to the frozen base model.
    """

    def __init__(self, numeric_dim, cat_dims, embed_dim=16):
        super().__init__()
        # 1. Numeric Projection
        self.num_proj = nn.Linear(numeric_dim, embed_dim)

        # 2. Categorical Embeddings (Independent from main model)
        self.embeddings = nn.ModuleList([
            nn.Embedding(n, embed_dim) for n in cat_dims
        ])

        # 3. MLP for Residuals
        self.net = nn.Sequential(
            nn.Linear(embed_dim * (len(cat_dims) + 1), 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, len(TARGETS))  # Outputs residuals for targets
        )

    def forward(self, x_num, x_cat):
        embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
        num_emb = self.num_proj(x_num)

        # Concat all
        x = torch.cat(embs + [num_emb], dim=1)
        return self.net(x)


# --- 2. UNIFIED VISCOSITY PREDICTOR ---

class ViscosityPredictor:
    """
    Unified predictor that handles:
    1. Standard Inference (predict)
    2. Uncertainty Estimation (predict_with_uncertainty)
    3. Adaptive Learning (learn)

    Supports lazy loading - the model is not loaded until first use.
    """

    def __init__(self, checkpoint_path: Union[str, List[str]], device: str = 'cpu', is_ensemble: bool = False):
        self.device = device
        self.is_ensemble = is_ensemble
        self.adapter = None  # Placeholder for the adaptive module

        # Store config for lazy loading
        self._checkpoint_path = checkpoint_path
        self._hydrated = False

        # These will be populated on hydration
        self.model = None
        self.processor = None
        self.best_params = None
        self.n_models = None

    @property
    def is_hydrated(self) -> bool:
        """Check if the model has been loaded."""
        return self._hydrated

    def hydrate(self) -> 'ViscosityPredictor':
        """
        Explicitly load the model from checkpoint.
        Returns self for method chaining.
        """
        if self._hydrated:
            return self

        if self.is_ensemble:
            self._load_ensemble(self._checkpoint_path)
        else:
            self._load_single_model(self._checkpoint_path)

        self.model.eval()
        self._hydrated = True
        return self

    def _ensure_hydrated(self):
        """Internal method to ensure model is loaded before use."""
        if not self._hydrated:
            self.hydrate()

    def _load_single_model(self, checkpoint_path: str):
        self.checkpoint_path = checkpoint_path
        self.model, self.processor, self.best_params = load_model_checkpoint(
            checkpoint_path, device=self.device
        )
        self.n_models = 1
        print(
            f"ViscosityPredictor: Loaded single model from {checkpoint_path}")

    def _load_ensemble(self, checkpoint_paths: Union[str, List[str]]):
        if isinstance(checkpoint_paths, str):
            if '*' in checkpoint_paths or Path(checkpoint_paths).is_dir():
                pattern = str(Path(checkpoint_paths) / '*.pt') if Path(
                    checkpoint_paths).is_dir() else checkpoint_paths
                checkpoint_list = sorted(glob.glob(pattern))
            else:
                checkpoint_list = [checkpoint_paths]
        else:
            checkpoint_list = checkpoint_paths

        if not checkpoint_list:
            raise ValueError("No checkpoint files provided for ensemble")

        self.model, self.processor, self.best_params = load_model_checkpoint(
            checkpoint_list[0], device=self.device)
        models = [self.model]
        for ckpt in checkpoint_list[1:]:
            m, _, _ = load_model_checkpoint(ckpt, device=self.device)
            models.append(m)

        self.model = EnsembleModel(models)
        self.n_models = len(models)
        print(f"ViscosityPredictor: Loaded ensemble of {self.n_models} models")

    # --- MAIN ADAPTATION ENTRY POINT ---

    def learn(self, df_new: pd.DataFrame, y_new: np.ndarray,
              epochs: int = 500, lr: float = 5e-3,
              analog_protein: Optional[str] = None):
        """
        The master entry point for adapting the model to new data.
        Handles the entire adaptation pipeline:
        1. Identifies and expands new categories (Smart Expansion).
        2. Initializes and trains a Gated Residual Adapter (Zero Forgetting).
        3. Attaches the adapter for immediate use.

        Args:
            df_new: DataFrame containing features of the new protein(s).
            y_new: Array of target viscosity values.
            epochs: Number of training epochs for the adapter.
            lr: Learning rate for the adapter.
            analog_protein: Name of an existing protein to use for initialization transfer (e.g., 'bsa').
        """
        self._ensure_hydrated()

        print(f"=== Starting Adaptation Pipeline ({len(df_new)} samples) ===")

        # 1. Detect and Expand Categories
        new_cats = self.processor.detect_new_categories(df_new)
        expanded_any = False

        for feature, categories in new_cats.items():
            print(
                f"  [Detection] Found new categories for {feature}: {categories}")
            for cat in categories:
                # Apply analog transfer only to Protein_type
                sim_cat = analog_protein if feature == 'Protein_type' else None
                self._smart_expand_category(
                    feature, cat, similar_category=sim_cat)
                expanded_any = True

        if not expanded_any:
            print(
                "  [Info] No new categories detected. Training adapter on existing feature space.")

        # 2. Train the Adapter
        self._train_gated_adapter(df_new, y_new, n_epochs=epochs, lr=lr)

        print("=== Adaptation Complete ===")

    # --- INTERNAL ADAPTATION METHODS ---

    def _smart_expand_category(self, feature_name: str, new_category: str, similar_category: Optional[str] = None):
        """Internal method to expand vocabulary with smart initialization."""
        if feature_name not in self.processor.categorical_features:
            return

        if new_category in self.processor.cat_maps[feature_name]:
            return

        print(f"  [Expansion] Adding '{new_category}' to {feature_name}...")
        self.processor.add_categories(feature_name, [new_category])

        # Handle embedding resizing (Assumes single model for adaptation currently)
        idx = self.model.cat_feature_names.index(feature_name)
        old_emb = self.model.embeddings[idx]
        new_vocab_size = old_emb.num_embeddings + 1

        new_emb_layer = nn.Embedding(new_vocab_size, old_emb.embedding_dim)

        with torch.no_grad():
            new_emb_layer.weight[:-1] = old_emb.weight

            if similar_category and similar_category in self.processor.cat_maps[feature_name]:
                try:
                    sim_idx = self.processor.cat_maps[feature_name].index(
                        similar_category)
                    noise = torch.randn(old_emb.embedding_dim) * 0.01
                    # Transfer + Boost (1.5x)
                    new_emb_layer.weight[-1] = (old_emb.weight[sim_idx]
                                                * 1.5) + noise
                    print(
                        f"  [Init] Initialized from analog '{similar_category}' (Boosted 1.5x)")
                except ValueError:
                    new_emb_layer.weight[-1] = old_emb.weight.mean(dim=0)
            else:
                new_emb_layer.weight[-1] = old_emb.weight.mean(dim=0)
                print(f"  [Init] Initialized from global mean")

        self.model.embeddings[idx] = new_emb_layer.to(self.device)
        self.model.cat_maps[feature_name].append(new_category)

    def _train_gated_adapter(self, df_new: pd.DataFrame, y_new: np.ndarray, n_epochs: int, lr: float):
        """Internal method to train the Gated Residual Adapter."""
        print("  [Adapter] Initializing Residual Adapter with Gating...")

        # 1. Setup
        cat_dims = [len(m) for m in self.processor.cat_maps.values()]
        num_dim = len(self.processor.numeric_features)

        self.adapter = ResidualAdapter(
            num_dim, cat_dims, embed_dim=16).to(self.device)
        optimizer = optim.Adam(self.adapter.parameters(), lr=lr)
        loss_fn = nn.MSELoss()

        # 2. Identify Gating Index (Assuming new protein is the last added)
        new_p_idx = len(self.model.cat_maps['Protein_type']) - 1
        print(f"  [Adapter] Gating active for Protein_type index: {new_p_idx}")

        # 3. Prepare Data
        X_num, X_cat = self.processor.transform(df_new)
        y_log = log_transform_targets(y_new)
        y_log_t = torch.tensor(y_log, dtype=torch.float32).to(self.device)

        with torch.no_grad():
            X_num_t, X_cat_t = to_tensors(X_num, X_cat)
            X_num_t = X_num_t.to(self.device)
            X_cat_t = X_cat_t.to(self.device)
            # Base model predicts (Frozen)
            base_preds = self.model(X_num_t, X_cat_t)

        target_residuals = y_log_t - base_preds

        # 4. Train Loop
        print(f"  [Adapter] Training on {len(df_new)} samples...")
        self.adapter.train()
        for epoch in range(n_epochs):
            optimizer.zero_grad()
            pred_residuals = self.adapter(X_num_t, X_cat_t)
            loss = loss_fn(pred_residuals, target_residuals)
            loss.backward()
            optimizer.step()

            if (epoch+1) % 100 == 0:
                print(f"    Epoch {epoch+1}: Loss {loss.item():.6f}")

        # 5. Attach
        self._attach_gated_adapter(new_p_idx)

    def hydrate_adapter(self, df_support: pd.DataFrame, n_epochs: int = 500, lr: float = 5e-3):
        """
        Restores the Gated Adapter state by training on a support set.
        Call this during deployment to 'awaken' the adapter for a specific protein.

        Args:
            df_support: DataFrame containing support samples with target columns.
                        Must contain 'Protein_type' column to identify which protein to gate.
            n_epochs: Number of training epochs for the adapter.
            lr: Learning rate for the adapter.
        """
        self._ensure_hydrated()

        print("  [Adapter] Hydrating Adapter State...")

        # 1. Dynamically identify the protein type from the support set
        if 'Protein_type' not in df_support.columns:
            raise ValueError("df_support must contain 'Protein_type' column")

        # Clean and normalize the protein type (matching the clean() function behavior)
        protein_types = df_support['Protein_type'].astype(
            str).str.strip().str.lower().unique()

        if len(protein_types) == 0:
            raise ValueError("No valid protein types found in df_support")
        if len(protein_types) > 1:
            warnings.warn(
                f"Multiple protein types found in support set: {list(protein_types)}. "
                f"Using the first one: '{protein_types[0]}'"
            )

        target_protein = protein_types[0]
        protein_map = self.processor.cat_maps.get('Protein_type', [])

        if target_protein not in protein_map:
            raise ValueError(
                f"Protein type '{target_protein}' not found in model vocabulary. "
                f"Known proteins: {protein_map}"
            )

        protein_idx = protein_map.index(target_protein)
        print(
            f"  [Adapter] Target protein: '{target_protein}' (index {protein_idx})")

        # 2. Setup Architecture
        cat_dims = [len(m) for m in self.processor.cat_maps.values()]
        num_dim = len(self.processor.numeric_features)
        self.adapter = ResidualAdapter(
            num_dim, cat_dims, embed_dim=16).to(self.device)

        # 3. Prepare Data
        X_num, X_cat = self.processor.transform(df_support)
        y_true = df_support[TARGETS].values
        y_log = log_transform_targets(y_true)

        with torch.no_grad():
            X_num_t, X_cat_t, y_log_t = to_tensors(X_num, X_cat, y_log)
            X_num_t = X_num_t.to(self.device)
            X_cat_t = X_cat_t.to(self.device)
            y_log_t = y_log_t.to(self.device)
            base_preds = self.model(X_num_t, X_cat_t)

        target_residuals = y_log_t - base_preds

        # 4. Train (Hydrate)
        optimizer = optim.Adam(self.adapter.parameters(), lr=lr)
        loss_fn = nn.MSELoss()

        self.adapter.train()
        for i in range(n_epochs):
            optimizer.zero_grad()
            pred = self.adapter(X_num_t, X_cat_t)
            loss = loss_fn(pred, target_residuals)
            loss.backward()
            optimizer.step()

        print(f"  [Adapter] Ready. Final Fitting Loss: {loss.item():.6f}")

        # 5. Attach with dynamically determined index
        self._attach_gated_adapter(protein_idx)

    def _attach_gated_adapter(self, protein_idx: int):
        """Internal method to monkey-patch the model forward pass."""
        if self.adapter is None:
            return

        self.adapter.eval()
        p_col_idx = self.model.cat_feature_names.index('Protein_type')
        original_forward = self.model.forward

        def new_forward(x_n, x_c):
            # A. Base Prediction (Frozen logic)
            base = original_forward(x_n, x_c)
            # B. Adapter Prediction
            adapt = self.adapter(x_n, x_c)
            # C. Gating: Only activate for the specific protein index
            mask = (x_c[:, p_col_idx] == protein_idx).float().unsqueeze(1)
            return base + (adapt * mask)

        self.model.forward = new_forward
        print("  [Adapter] Gated Mechanism attached successfully.")

    # --- INFERENCE METHODS ---

    def predict(self, df: pd.DataFrame, return_log_space: bool = False, batch_size: int = 256) -> np.ndarray:
        """Standard prediction. Works for both base and adapted models."""
        self._ensure_hydrated()

        self.model.eval()

        # Check for new categories (for simple labeling/inference compatibility)
        new_cats = self.processor.detect_new_categories(df)
        if new_cats:
            for feature, categories in new_cats.items():
                expand_processor_and_model(
                    self.processor, self.model, feature, categories)

        X_num, X_cat = self.processor.transform(df)
        X_num_t, X_cat_t = to_tensors(X_num, X_cat)
        X_num_t = X_num_t.to(self.device)
        X_cat_t = X_cat_t.to(self.device)

        predictions = []
        with torch.no_grad():
            for i in range(0, len(X_num_t), batch_size):
                batch_num = X_num_t[i:i+batch_size]
                batch_cat = X_cat_t[i:i+batch_size]
                pred = self.model(batch_num, batch_cat)
                predictions.append(pred.cpu().numpy())

        predictions = np.vstack(predictions)
        if not return_log_space:
            predictions = inverse_log_transform(predictions)
        return predictions

    def predict_with_uncertainty(self, df: pd.DataFrame, n_samples: int = 30, confidence_level: float = 0.95) -> Dict[str, np.ndarray]:
        """
        Predicts with uncertainty using Monte Carlo Dropout.
        """
        self._ensure_hydrated()

        self.model.train()  # Enable Dropout

        # Ensure categories exist
        new_cats = self.processor.detect_new_categories(df)
        if new_cats:
            for feature, categories in new_cats.items():
                expand_processor_and_model(
                    self.processor, self.model, feature, categories)

        X_num, X_cat = self.processor.transform(df)
        X_num_t, X_cat_t = to_tensors(X_num, X_cat)
        X_num_t = X_num_t.to(self.device)
        X_cat_t = X_cat_t.to(self.device)

        mc_preds = []
        for _ in range(n_samples):
            with torch.no_grad():
                pred = self.model(X_num_t, X_cat_t)
                mc_preds.append(pred.cpu().numpy())

        mc_preds = np.array(mc_preds)
        mc_preds_linear = inverse_log_transform(mc_preds)

        mean_pred = mc_preds_linear.mean(axis=0)
        std_pred = mc_preds_linear.std(axis=0)

        alpha = 1 - confidence_level
        lower = np.percentile(mc_preds_linear, (alpha/2)*100, axis=0)
        upper = np.percentile(mc_preds_linear, (1 - alpha/2)*100, axis=0)

        self.model.eval()

        return {
            "mean": mean_pred,
            "std": std_pred,
            "lower_ci": lower,
            "upper_ci": upper
        }

    def save_checkpoint(self, filepath: str):
        self._ensure_hydrated()
        save_model_checkpoint(self.model, self.processor,
                              self.best_params, filepath)
        print(f"Saved checkpoint to: {filepath}")


if __name__ == "__main__":
    print("Inference Module Loaded.")
    print("ViscosityPredictor now supports .learn() for adaptation.")
    print("ViscosityPredictor supports lazy loading - model loads on first use.")
