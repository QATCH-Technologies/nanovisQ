import math
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, Optional, Tuple

# from logger import get_logger
from common import Common
from config import VisQ2xConfig
from model import VisQ2xModel
from losses import ViscosityLoss
from continual_learning import EWC, ERB

TAG = "[Predictor]"


class Predictor(Common):
    def __init__(self, config: VisQ2xConfig) -> None:
        super().__init__(config=config)
        # self.logger = get_logger(name=TAG)
        self.ewc = None
        self.replay_buffer = ERB(max_size=self.config.replay_buffer_size)

    def _enable_dropout(self):
        for module in self.model.modules():
            if isinstance(module, nn.Dropout):
                module.train()

    def _add_new_category(self, df: pd.DataFrame, verbose: bool = False) -> None:
        new_categories_added = {}
        for col in self.categorical:
            if col in df.columns:
                new_categories = set(df[col].dropna().unique())
                existing = set(self.embedder.mappings[col].keys())
                new = new_categories - existing

            if new:
                # if verbose:
                # self.logger.info(f"Found new categories in {col}: {new}")

                new_categories_added[col] = list(new)
                for cat in new:
                    self.embedder.add(column=col, new_category=cat)

                    new_vocab_size = len(self.embedder.mappings[col])
                    self.model.expand(
                        feature=col, new_vocab_size=new_vocab_size)

        return new_categories_added

    def _train_epoch_with_ewc(self, loader, optimizer, criterion) -> float:
        losses = []
        for batch in loader:
            num_batch, cat_batch, targets_batch = batch
            num_batch = num_batch.to(self.device)
            cat_batch = {k: v.to(self.device) for k, v in cat_batch.items()}
            targets_batch = targets_batch.to(self.device)

            optimizer.zero_grad()
            outputs = self.model(num_batch, cat_batch)
            loss = criterion(outputs, targets_batch)

            if self.ewc is not None:
                loss += self.config.ewc_lambda * self.ewc.penalty()

            loss.backward()
            optimizer.step()
            losses.append(loss.item())

        return np.mean(losses)

    def _replay_epoch(self, optimizer, criterion) -> float:
        losses = []
        samples = self.replay_buffer.sample(batch_size=self.config.batch_size)
        if not samples:
            # self.logger.warning("No samples found for ERB; returning 0.0")
            return 0.0
        for replay in samples:
            numeric_replay, cat_replay, targets_replay = replay
            numeric_replay = numeric_replay.to(self.device)
            cat_replay = {
                k: v.to(self.device) for k, v in cat_replay.items()}
            targets_replay = targets_replay.to(self.device)

            optimizer.zero_grad()
            replay_outputs = self.model(numeric_replay, cat_replay)
            replay_loss = criterion(replay_outputs, targets_replay)
            replay_loss.backward()
            optimizer.step()

            losses.append(replay_loss.item())

        return np.mean(losses) if losses else 0.0

    def predict(self, df: pd.DataFrame, return_uncertainty: bool = False, ci_range: tuple = (2.5, 97.5), n_samples: int = 50) -> Tuple:
        if self.model is None:
            # self.logger.error("Model is not trained")
            raise ValueError

        numerical, categoric, _ = self.preprocess(df=df, fit_scalers=False)
        loader = self.create_loaders(
            numeric=numerical, categoric=categoric, targets=None, shuffle=False)

        if not return_uncertainty:
            self.model.eval()
            preds = []
            with torch.no_grad():
                for batch in loader:
                    num_batch, cat_batch = batch
                    num_batch = num_batch.to(self.device)
                    cat_batch = {k: v.to(self.device)
                                 for k, v in cat_batch.items()}
                    outputs = self.model(num_batch, cat_batch)
                    preds.append(outputs.cpu().numpy())
            preds = np.vstack(preds)
            # self.logger.info(
            #    f"Predicting viscosity_profile=[{np.expm1(preds)}]")
            return np.expm1(preds)

        else:
            self._enable_dropout()

            all_predictions = []
            for _ in range(n_samples):
                preds = []
                with torch.no_grad():
                    for batch in loader:
                        num_batch, cat_batch = batch
                        num_batch = num_batch.to(self.device)
                        cat_batch = {k: v.to(self.device)
                                     for k, v in cat_batch.items()}
                        outputs = self.model(
                            num_batch, cat_batch)
                        preds.append(outputs.cpu().numpy())
                all_predictions.append(np.vstack(preds))

            all_predictions = np.stack(all_predictions, axis=0)
            mean_pred = np.mean(all_predictions, axis=0)
            std_pred = np.std(all_predictions, axis=0)
            lower_95 = np.percentile(all_predictions, ci_range[0], axis=0)
            upper_95 = np.percentile(all_predictions, ci_range[1], axis=0)
            mean_pred = np.expm1(mean_pred)
            std_pred_original = np.expm1(mean_pred + std_pred) - mean_pred
            lower_95 = np.expm1(lower_95)
            upper_95 = np.expm1(upper_95)

            self.model.eval()

            uncertainty = {
                'std': std_pred_original,
                'lower_95': lower_95,
                'upper_95': upper_95,
                'coefficient_of_variation': std_pred_original / (mean_pred + 1e-8)
            }
            # self.logger.info(
            #    f"Predicting with uncertainty viscosity_profile=[{mean_pred}], uncerainty=[{uncertainty}]")
            return mean_pred, uncertainty

    def learn(self, new_df: pd.DataFrame, n_epochs: Optional[int], verbose: bool = True) -> Dict:
        if self.model is None:
            # self.logger.error("Model is not trained")
            raise ValueError

        n_epochs = n_epochs or min(50, self.config.epochs//2)
        new_categories = self._add_new_category(new_df, verbose)

        numeric, categoric, targets = self.preprocess(
            new_df, fit_scalers=False)
        loader = self.create_loaders(
            numeric=numeric, categoric=categoric, targets=targets)

        optimizer = optim.AdamW(self.model.parameters(),
                                lr=self.config.adaptation_lr)
        criterion = ViscosityLoss()
        self.model.train()
        losses = []
        for epoch in range(n_epochs):
            ewc_loss = self._train_epoch_with_ewc(
                loader=loader, optimizer=optimizer, criterion=criterion)
            replay_loss = self._replay_epoch(
                optimizer=optimizer, criterion=criterion)
            losses.append(ewc_loss)
            # if verbose:
            # self.logger.info(
            #   f"Epoch {epoch} - EWC Loss: {ewc_loss:.4f}, Replay Loss {replay_loss:.4f}")

        self.ewc = EWC(self.model, loader, self.device)
        self.replay_buffer.update(
            loader, n_samples=self.config.replay_buffer_size)
        # if verbose:
        # self.logger.info("Incremental learn complete.")

        return {
            'avg_loss': np.mean(losses),
            'new_categories_added': new_categories,
            'n_epochs': n_epochs
        }

    def load(self, path: str):
        checkpoint = self.load_state(path=path)
        vocab_sizes = self.embedder.get_vocab_sizes()
        self.model = VisQ2xModel(
            numerical_features=len(self.numeric),
            vocab_sizes=vocab_sizes,
            embedding_dims=self.embedder.embedding_dims,
            hidden_layers=self.config.hidden_layers,
            output_size=len(self.targets),
            dropout_rate=self.config.dropout_rate
        ).to(self.device)
        self.model.load_state_dict(checkpoint['model_state'])
        self.model.eval()
        # self.logger.info(f"Predictor loaded from {path}")
